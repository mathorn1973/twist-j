"""Verify this local bundle's exact inventory and bytes; execute no science."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS'
expected = {}
for line in manifest.read_text(encoding='utf-8').splitlines():
    digest, name = line.split('  ', 1)
    target = (root / name).resolve()
    if not target.is_relative_to(root) or name in expected:
        raise ValueError(f'Invalid manifest path: {name}')
    raw = target.read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError(f'Hash mismatch: {name}')
    expected[name] = digest
actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
          if p.is_file() and p != manifest and '__pycache__' not in p.parts}
if actual != set(expected):
    raise ValueError(f'Inventory mismatch: extra={actual-set(expected)}, missing={set(expected)-actual}')
print(f'PASS: {len(expected)} files; exact inventory and SHA-256; no scientific execution')

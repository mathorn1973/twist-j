"""Capture exactly one frozen local verifier run; preserve success or failure."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
RUN = ROOT/'runs'/'001'
SOURCE = Path('D:/twistj/.codex-worktrees/native-carrier-clock-prep')


def blob(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_bytes((json.dumps(value, sort_keys=True, indent=2)+'\n').encode('utf-8'))


pin = json.loads((ROOT/'PIN.json').read_text(encoding='utf-8'))
for name, value in pin['files'].items():
    if blob(ROOT/name) != value:
        raise RuntimeError('pre-execution immutable input mismatch: '+name)
RUN.mkdir(parents=True, exist_ok=False)
command = [sys.executable, '-B', str(ROOT/'verify.py'), '--source-root', str(SOURCE),
           '--output', str(RUN/'data')]
changes = {'PYTHONHASHSEED': '0', 'PYTHONDONTWRITEBYTECODE': '1', 'LC_ALL': 'C',
           'LANG': 'C', 'TZ': 'UTC'}
env = os.environ.copy()
env.update(changes)
record = {'started_utc': datetime.now(timezone.utc).isoformat(), 'command': command,
          'working_directory': str(ROOT), 'environment': changes, 'timeout_seconds': 600,
          'python': sys.version, 'implementation': platform.python_implementation(),
          'platform': platform.platform(), 'architecture': platform.machine(),
          'pin': blob(ROOT/'PIN.json'), 'inputs_before': pin['files']}
save(RUN/'BEFORE.json', record)
try:
    process = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=600)
    stdout, stderr = process.stdout, process.stderr
    record['returncode'] = process.returncode
except subprocess.TimeoutExpired as exc:
    stdout, stderr = exc.stdout or b'', exc.stderr or b''
    record['returncode'] = None
    record['failure'] = 'TIMEOUT; original frozen inputs retained'
(RUN/'stdout.txt').write_bytes(stdout)
(RUN/'stderr.txt').write_bytes(stderr)
record['finished_utc'] = datetime.now(timezone.utc).isoformat()
record['stdout'] = blob(RUN/'stdout.txt')
record['stderr'] = blob(RUN/'stderr.txt')
record['inputs_after'] = {name: blob(ROOT/name) for name in pin['files']}
record['inputs_unchanged'] = record['inputs_after'] == record['inputs_before']
save(RUN/'RUN.json', record)
print(json.dumps({'run': str(RUN), 'returncode': record['returncode'],
                  'stdout': record['stdout'], 'stderr': record['stderr'],
                  'inputs_unchanged': record['inputs_unchanged']}, sort_keys=True))
sys.exit(0 if record['returncode'] == 0 and record['inputs_unchanged'] else 1)

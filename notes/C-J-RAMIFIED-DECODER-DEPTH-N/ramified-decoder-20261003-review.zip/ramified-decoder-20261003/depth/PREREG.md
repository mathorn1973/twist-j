# C-J-RAMIFIED-DECODER-DEPTH-N — local exact census, version 1

2026-10-04 Europe/Prague (2026-10-03 UTC preparation). PUBLIC-content, NON-CANONICAL, L1 incubation. No public identifier reservation, formal probe, GitHub write or Canon change. Finite census ceiling: candidate-C on one architecture. New computation is authorized only after this file and verify.py are recorded in PIN.json by SHA-256 and byte count. No exploratory scientific calculation has preceded this pin.

## Authority, source and exposure

Public main is `5e872c22a18043c8126945a982efad55472cea82`, Public Canon v97. STATUS, POLICY, AGENTS, CORE and FRONTIER were read at these same exact bytes; the coordinator freshly verified main, the authority gate and clean checkout. `../audit/COLLISIONS.md` releases this local scope, preserving #1283's sealed decoder and the separate #1294/#1296/#970 scopes. No closed object is reopened.

Inputs are the current registered J-TWO-TRACE-RESIDUE-INVERSE [T], J-OBSERVED-SCALAR-CODE-CAPACITY [T], their `probes/P-J-TWO-TRACE-RESIDUE-DECODER-1/{PROOF.md,PREREG.md,decoder.py,primary.py,break.py,verify.py,RESULT.md,EXPECTED.txt}`, and canonical C20-TEICHMULLER-SPLIT [T] for `(5)=(lambda)^4`. The exact source hashes and sizes are frozen in SOURCE.json and PIN.json. Code is newly authored for this local refinement. Existing implementation and answers were read; neither author independence nor result blinding is claimed.

Exposed anchors: strip size 3150, below-bound940 size 3110, trace classes145, sorted-strip SHA256 `6a08d7de33b4cadb615f942b37202540dd6dea0f59f2412ffb822389c7c1cdab`, full mod5 keys2603, full mod25 keys3150. No partial-depth counts are known before execution. The coordinator supplied the pre-run analytical upper bound: equal traces give `N(alpha-beta)<=16*941=15056`, whereas a nonzero multiple of lambda^6 has norm at least `5^6=15625`; thus depths6–8 should be injective. This is disclosed input, not an independent finding or numerical prediction chosen after the run.

## Exact carrier and observations

`O=Z[zeta]`, `Phi5(zeta)=0`, ordered basis `(1,zeta,zeta²,zeta³)`, `lambda=1-zeta`, `J=1+zeta²`, `phi=-zeta²-zeta³`. Scalars are ordered four-integer tuples with literal coefficient equality. For `alpha=(a,b,c,d)` freeze

```text
u=a²-ab+b²-bc+c²-cd+d²
v=ab-ac-ad+bc-bd+cd
N=u²+uv-v², S0=2u+v, S1=3u-v.
B941={alpha: 0<=v<u and 1<=N<=941}.
```

This is the COMPLETE original oriented half-open strip `1<=A/B<phi^4`, not a selected codebook or finite segment of J powers. Public PROOF sections4–5 prove every member lies in `[-8,8]^4` via `S<=92` and `c_i²<=368/5<81`. Scan the complete83521 integer vectors in that box, preserving strict upper/inclusive lower endpoints and norm941. Zero is excluded. The sorted strip must have exactly the public digest above.

For each k=1,...,8, `D_k(alpha)=(S0,S1,alpha mod lambda^k O)`. No separately supplied native time or physical readout is introduced. Primary residue representation is k canonical digits in `{0,...,4}`, least significant first, obtained by exact repeated lambda division. If x=(a,b,c,d), its residue modulo lambda is `r=sum(x) mod5`. Subtract `(r,0,0,0)` and divide by lambda exactly. For y with sum divisible by5, set

```text
t=(y0+y1+y2+y3)/5
y/lambda=(y0-t, y0+y1-2t, y0+y1+y2-3t, t).
```

The multiplication inverse is checked by `lambda*(A,B,C,D)=(A+D,B-A+D,C-B+D,2D-C)`. Repeated divisions give `alpha=sum_(i<k) r_i lambda^i + lambda^k q`. These digits describe ideal congruence; they are not truncated original coefficients. Evaluation at zeta=1 modulo5 identifies O/lambda O with F5, so recursive equality of k digits is equivalent to divisibility of the difference by lambda^k.

## Independent-method validation and frozen audits

Only Python standard-library exact integers and Fraction are allowed; no float, numerical embedding or ad hoc residue truncation. No existing scientific module is imported or executed.

1. Derive ring multiplication independently by ordinary polynomial convolution and repeated reduction of zeta^4 by `-1-zeta-zeta²-zeta³`. Derive conjugation and all four Galois actions in that ring. On every included strip scalar independently recompute `alpha*bar(alpha)`, S0,S1 and its four-conjugate norm; compare with the coordinate formulas. Check J/J-inverse, both strip endpoints and lambda multiplication on the four basis vectors.
2. Build the exact integer multiplication matrix M of lambda from that ring algorithm. Build each M^k and its Fraction inverse by exact Gaussian elimination. Require determinant5^k and verify both matrix-inverse identities. Use denominator5^k to obtain an integer inverse numerator. For any integer delta, `delta in lambda^k O` iff all components of `M^(-k)delta` are integers. This lattice test uses no primary digit division.
3. For every strip scalar and k, reconstruct its primary digits/remainder exactly, and validate `alpha-representative` with the independent matrix ideal test. For every unordered pair with the same two traces, compare digit equality at all8 depths with independent matrix divisibility. At k4/k8 additionally compare this equivalence with coefficientwise mod5/mod25 equality. Also compare complete key counts with direct coefficient-modulus keys. Pair tests are exhaustive within every two-trace fibre, not sampled.
4. Require all exposed strip/trace/digest anchors, k4=2603 and k8=3150. Any anchor mismatch is STOP; do not report adjusted capacities. Independently check nondecreasing counts and injectivity at k6–8 against the disclosed norm argument. A conflict is preserved and cannot be repaired by changing the carrier or threshold.
5. Validate each nonzero equal-trace difference by exact norm: `N(delta)<=16*N(alpha)`, and for every divisible depth `5^k` divides N(delta). Record the exact distribution of lambda valuations among all equal-trace unordered pairs; a pair coinciding through depth8 is an anchor failure. Valuation is the first differing digit, independently confirmed by the lattice tests.

## Outputs and exact witness ordering

For each k output key count K_k, `min(3125,K_k)`, shortfall `max(0,3125-K_k)`, injectivity, number of nonsingleton fibres, largest fibre, fibre-size histogram, number of unordered colliding pairs and a digest of all lexicographically key-sorted fibres with lexicographically sorted coefficient members. Record first k with K_k>=3125 and first k with K_k=3150; report NONE if absent rather than redefining success.

For every noninjective depth, including every depth insufficient for3125 labels, return two structured exact witnesses:

- `lexicographic_pair`: the least ordered pair `(left,right)` in ordinary integer tuple lexicographic order, with left<right, among ALL unordered collisions. This ordering depends on the original coefficient basis, not a residue naming convention.
- `least_norm_pair`: the least tuple `(N(left),left,right)` among ALL collisions, for an explicit small-norm comparison. It is separate from the lexicographic witness.

Each witness includes left/right coefficient vectors, common u,v,N,S0,S1, canonical k residue digits, nonzero delta=right-left, N(delta), exact lambda valuation, and integer coefficients of delta/lambda^k from BOTH methods. Include next digits demonstrating separation at valuation+1. For injective depths both witnesses are null. No ordering may be changed after inspection.

Write canonical UTF-8/LF files `STRIP.json`, `KEYS.json` (all8 complete fibre partitions), `CENSUS.json` (all8 counts and witnesses), `PAIR_VALUATIONS.json`, and a per-output hash/byte manifest. JSON uses sorted object keys, indent2, ensure_ascii=True, final LF. The special strip digest uses the source's compact sorted-list encoding without final LF. stdout uses deterministic one-line compact JSON; stderr must be empty on success. Do not fabricate EXPECTED.txt for this incubation.

## Failure, execution and status

First execution runs once from immutable local inputs, with a fresh `runs/001` directory and separate raw stdout/stderr. The verifier refuses an existing output data directory, verifies PIN file hashes and public source hashes before calculation, and refuses Python optimization. Capture actual command, Python/platform/architecture, start/end UTC, return code, stdout/stderr hashes/bytes, and output manifest. Environment: PYTHONHASHSEED=0, PYTHONDONTWRITEBYTECODE=1, LC_ALL=C, LANG=C, TZ=UTC. Budget600 seconds.

Zero tolerance for incomplete domain, incorrect residue equivalence, arithmetic mismatch, nonminimal witness, missing pair/fibre, differing anchors or custody. A scientific falsifier or code defect remains preserved with the failed version and exact output. Any repair requires new versioned preregistration/code/pin and a new run directory; never alter this frozen version or its thresholds. Hash/authority/ownership discrepancies STOP before calculation.

The result is candidate-C for this one-architecture complete finite census. After seeing the result, write a separately labelled structural discussion: distinguish existing theorems, the coordinator's pre-run norm bound, census-dependent minima, and any further analytical proof. No all-observable minimality, finite-memory storage claim, native apparatus, physical acquisition, energy, probability, event, codebook selection or new canonical status follows.

# Frozen execution record

Local incarnation: `C-J-RAMIFIED-DECODER-DEPTH-N`, version 1. Public source commit: `5e872c22a18043c8126945a982efad55472cea82`. First and only scientific execution. Status: PASS, candidate-C; no public formal probe.

The source code and preregistration were statically reviewed by the coordinator before execution. The pre-run freeze was saved at `2026-10-03T22:07:38.7389276Z`, and its hashes were sent to the coordinator before running.

| Frozen file | Bytes | SHA-256 |
|---|---:|---|
| PREREG.md | 9357 | `b03970500cacbf7b4ff0b102e1f92e269c3f87788e4ff48efd0b12553214a2fb` |
| verify.py | 14471 | `47f8bb4929aef21068ca14e09cd65046a6ab11aad768cdf7de48930041e44dd6` |
| SOURCE.json | 3548 | `b8eb49517b69874c0a1df2e90c0a215cf635de6dfa9ac538d29ce196ce21aca5` |
| run_frozen.py | 2691 | `56df938a9b3f9af7ec8b0536c78534bbbfe5784337e19d925bfd1fe06a530308` |
| PIN.json | 949 | `fce6469d183e4d3a2e4a161e13b887db050c22e150cd839fa2ff2858a3227f44` |

Actual launcher command:

```text
C:/Users/marek/AppData/Local/Programs/Python/Python312/python.exe -B D:/twistj/research/ramified-decoder-20261003/depth/run_frozen.py
```

Actual scientific subprocess argument vector (also stored structurally in RUN.json):

```text
C:\Users\marek\AppData\Local\Programs\Python\Python312\python.exe -B D:\twistj\research\ramified-decoder-20261003\depth\verify.py --source-root D:\twistj\.codex-worktrees\native-carrier-clock-prep --output D:\twistj\research\ramified-decoder-20261003\depth\runs\001\data
```

Working directory: `D:\twistj\research\ramified-decoder-20261003\depth`.

Environment: CPython 3.12.10, `[MSC v.1943 64 bit (AMD64)]`; `Windows-11-10.0.26300-SP0`; architecture `AMD64`; `PYTHONHASHSEED=0`, `PYTHONDONTWRITEBYTECODE=1`, `LC_ALL=C`, `LANG=C`, `TZ=UTC`; no Python optimization; timeout 600 seconds. The scientific calculation used Python exact integers and Fraction only.

Started: `2026-10-03T22:07:58.714185+00:00`. Finished: `2026-10-03T22:08:03.357136+00:00`. Return code: **0**. All four pinned input byte streams were rehashed after execution and remained unchanged.

| Evidence file | Bytes | SHA-256 |
|---|---:|---|
| runs/001/stdout.txt | 7088 | `2fb1749e70249df58062ec6ca2bea339598523c9968e7237d48eac82b609f441` |
| runs/001/stderr.txt | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| runs/001/data/CENSUS.json | 12724 | `8867312f381ba971a591e0da0a7817ea16caa115cb7feea7253fe6504e6ba90d` |
| runs/001/data/KEYS.json | 4458843 | `034571897deaeca53eb18e2a5145d837b00354ec98cc1b1730a830d5e53d06d4` |
| runs/001/data/PAIR_VALUATIONS.json | 1100 | `d99ac3806ff37e2ecaea31e6fdfeecfe1749381da0fc1b2e4584ee94deb9ed6d` |
| runs/001/data/STRIP.json | 118925 | `e89c905245aa50fd78cba5a54b9ecb7ef87f1b80efbde396fb1a6c5a8b751793` |

The digest of STRIP.json above hashes the descriptive JSON file. The inherited strip anchor hashes only the compact sorted coefficient list without a final newline and is `6a08d7de33b4cadb615f942b37202540dd6dea0f59f2412ffb822389c7c1cdab`. They intentionally hash different serializations.

Custody files: [PIN.json](PIN.json), [SOURCE.json](SOURCE.json), [BEFORE.json](runs/001/BEFORE.json), [RUN.json](runs/001/RUN.json), [MANIFEST.json](runs/001/data/MANIFEST.json). Readable scientific results: [RESULT.md](RESULT.md). Subsequent prose and analytical arguments are explicitly post-run material and were not part of the frozen execution inputs.

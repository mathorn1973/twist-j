# Ramified decoder depth: exact local census

Status: **PASS; NON-CANONICAL candidate-C**, L1, one architecture. Local incubation identifier `C-J-RAMIFIED-DECODER-DEPTH-N`; no public claim reservation, formal probe, or Canon change. Public source pin: `5e872c22a18043c8126945a982efad55472cea82` (Public Canon v97). This report follows the first and only execution of the immutable [preregistration](PREREG.md) and [verifier](verify.py).

## Result

On the complete original oriented strip

`B941 = {alpha in Z[zeta5] : 0 <= v < u, 1 <= u^2+uv-v^2 <= 941}`,

containing exactly **3150 scalars**, set `D_k(alpha)=(S(alpha),S(J alpha),alpha mod lambda^k O)`, where `lambda=1-zeta5`, `J=1+zeta5^2`, `S0=2u+v`, and `S1=3u-v`. The original ordered basis is `(1,zeta5,zeta5^2,zeta5^3)`. Neither the strip nor its endpoints were changed.

| k | Distinct keys K_k | Usable native labels min(3125,K_k) | Shortfall from 3125 | Nonsingleton fibres | Largest fibre | Unordered colliding pairs | Injective |
|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 256 | 256 | 2869 | 256 | 40 | 21125 | No |
| 2 | 1170 | 1170 | 1955 | 1090 | 20 | 5520 | No |
| 3 | 1384 | 1384 | 1741 | 1274 | 10 | 2730 | No |
| 4 | 2603 | 2603 | 522 | 493 | 10 | 645 | No |
| 5 | 2882 | 2882 | 243 | 262 | 5 | 280 | No |
| 6 | 3150 | 3125 | 0 | 0 | 1 | 0 | Yes |
| 7 | 3150 | 3125 | 0 | 0 | 1 | 0 | Yes |
| 8 | 3150 | 3125 | 0 | 0 | 1 | 0 | Yes |

Both requested minima are **k=6**: the first depth admitting at least 3125 distinct strip keys and the first depth injective on all 3150 strip scalars. These are initially conclusions of the frozen finite census. [STRUCTURAL-PROOF.md](STRUCTURAL-PROOF.md) separately proves both thresholds at candidate-T level: the norm bound proves depth-six injectivity, and thirty disjoint depth-five collision pairs give `K_5<=3120<3125` using the inherited strip cardinality. [CAPACITY-REVIEW.md](CAPACITY-REVIEW.md) accepts that analytical argument. This does not change the run's candidate-C status or manufacture a proof of every exact intermediate count.

## Frozen witness ordering and witnesses

Each unordered collision is oriented `left < right` in ordinary integer tuple lexicographic order. The required witness is the smallest `(left,right)` over all collisions at that depth. This ordering was fixed before execution. The following are those witnesses; digits are least significant first in the exact lambda-adic expansion with representatives `0,1,2,3,4`.

| k | left | right | Common (u,v); N | Common (S0,S1) | Common residue digits | v_lambda(right-left) |
|---:|---|---|---|---|---|---:|
| 1 | (-6,-7,-6,-3) | (-3,-6,-7,-6) | (28,27); 811 | (83,57) | (3) | 3 |
| 2 | (-6,-7,-6,-3) | (-3,-6,-7,-6) | (28,27); 811 | (83,57) | (3,3) | 3 |
| 3 | (-6,-7,-6,-3) | (-3,-6,-7,-6) | (28,27); 811 | (83,57) | (3,3,0) | 3 |
| 4 | (-6,-6,-6,-2) | (4,4,4,-2) | (28,24); 880 | (80,60) | (0,4,3,2) | 4 |
| 5 | (-6,-6,-5,-4) | (-1,-1,5,1) | (27,8); 881 | (62,73) | (4,3,3,4,0) | 5 |

For the independent, separately frozen ordering `(N(left),left,right)`, the least-norm collisions are:

| k | left | right | Common N | Common (S0,S1) | Common residue digits | (right-left)/lambda^k |
|---:|---|---|---:|---|---|---|
| 1 | (-1,-1,-1,-1) | (0,0,0,1) | 1 | (2,3) | (1) | (0,0,0,1) |
| 2 | (-1,-2,-1,-1) | (-1,0,0,1) | 5 | (5,5) | (0,2) | (-1,-1,-1,0) |
| 3 | (-2,-2,-2,-1) | (2,1,0,0) | 11 | (8,7) | (3,4,0) | (-1,-1,0,1) |
| 4 | (-3,-3,-3,-1) | (2,2,2,-1) | 55 | (20,15) | (0,2,4,1) | (-1,-3,-3,-1) |
| 5 | (-3,-5,-3,-3) | (2,5,2,2) | 211 | (32,33) | (1,0,3,3,3) | (1,0,-2,-2) |

The minimality assertions in both tables depend on complete enumeration. The direct validity of each displayed pair is separately checkable by substitution. [CENSUS.json](runs/001/data/CENSUS.json) preserves every structured witness, both independently obtained division quotients, difference norm, and first separating digit. Injective depths have null witnesses. The original public mod-5 norm-55 witness uses a different ordering; no contradiction or replacement is claimed.

## Exact carrier and independent-method checks

The public strip/range proof confines the complete domain to `[-8,8]^4`. The frozen verifier examined all 83521 coefficient vectors, obtained 3150 strip elements and 145 trace classes, and matched the original compact sorted-strip digest `6a08d7de33b4cadb615f942b37202540dd6dea0f59f2412ffb822389c7c1cdab`. Both hard anchors passed unchanged: **k4=2603**, equivalent to the original mod-5 partition, and **k8=3150**, equivalent to the original mod-25 partition.

Primary residues use repeated exact division by `lambda`, after subtracting `sum(coefficients) mod 5`. Independent validation uses ordinary polynomial ring multiplication, the integer matrix of multiplication by `lambda`, its exact powers, and Fraction inverses. Matrix ideal membership does not call the primary division routine. Determinants were checked as `5^k`, both inverse identities were checked, and all 3150 scalar reconstructions were checked at all eight depths.

All 36975 unordered equal-trace pairs were checked at all eight depths: **295800 independent matrix congruence comparisons**. No mismatch occurred. At depths 4 and 8, direct coefficientwise mod-5/mod-25 equivalence was additionally checked. Every included scalar's norm and traces were independently checked by ring/Galois operations. Every equal-trace difference satisfied the disclosed norm bound and the applicable norm-divisibility tests. This is method independence within one author implementation, not an independent author or second architecture.

The exact lambda-valuation histogram of equal-trace differences was `0:15850, 1:15605, 2:2790, 3:2085, 4:365, 5:280`. Its maximum was 5. [PAIR_VALUATIONS.json](runs/001/data/PAIR_VALUATIONS.json) preserves this audit. [KEYS.json](runs/001/data/KEYS.json) contains all eight complete partitions, not only their counts; [STRIP.json](runs/001/data/STRIP.json) contains the complete original domain.

## Execution, evidence status, and limits

One frozen run, one architecture, return code 0, empty stderr, all inputs unchanged. No failed run, repair, threshold change, domain change, or second scientific execution occurred. [RUN.md](RUN.md) records the command, environment and hashes; [RUN.json](runs/001/RUN.json) and raw [stdout](runs/001/stdout.txt) preserve the execution evidence. Source hashes, byte counts and Git blob identities are in [SOURCE.json](SOURCE.json); frozen input hashes are in [PIN.json](PIN.json).

The eight exact counts, fibre sizes, collision multiplicities, witness minimality and valuation histogram remain **candidate-C** finite findings. The separately written analytical argument can support narrower candidate-T conclusions without upgrading this execution into an independent theorem or public check.

The native-label interpretation inherits the registered observed-reader class, its global comparison across sheets, and its omitted separately supplied sheet number. Multiplication by the unit J preserves each lambda-power ideal, so its normalization/attainment argument applies to these ideal residues. No explicit native dictionary is selected here. This work proves no physical acquisition, finite storage of unbounded traces, general all-observable optimality, new apparatus, or reopened claim in the adjacent sealed notes.

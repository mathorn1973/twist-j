#!/usr/bin/env python3
"""Frozen local exact lambda-depth census; no public or physical promotion."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
from itertools import combinations, product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
ZERO = (0, 0, 0, 0)
ONE = (1, 0, 0, 0)
LAM = (1, -1, 0, 0)
J = (1, 0, 1, 0)
JI = (0, -1, -1, 0)
STRIP_DIGEST = '6a08d7de33b4cadb615f942b37202540dd6dea0f59f2412ffb822389c7c1cdab'


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def compact(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def digest(value):
    return hashlib.sha256(compact(value).encode('utf-8')).hexdigest()


def add(a, b):
    return tuple(x+y for x, y in zip(a, b))


def subtract(a, b):
    return tuple(x-y for x, y in zip(a, b))


def mul(a, b):
    raw = [0]*7
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            raw[i+j] += x*y
    for i in range(6, 3, -1):
        value = raw[i]
        for j in range(1, 5):
            raw[i-j] -= value
        raw[i] = 0
    return tuple(raw[:4])


def power(a, n):
    out = ONE
    for _ in range(n):
        out = mul(out, a)
    return out


def galois(a, exponent):
    root = power((0, 1, 0, 0), exponent)
    out = ZERO
    for i, c in enumerate(a):
        out = add(out, tuple(c*x for x in power(root, i)))
    return out


def rational(a, label):
    require(a[1:] == (0, 0, 0), (label, a))
    return a[0]


def ring_norm(a):
    out = ONE
    for e in (1, 2, 3, 4):
        out = mul(out, galois(a, e))
    return rational(out, 'absolute norm')


def inspect(a):
    x, y, z, w = a
    u = x*x-x*y+y*y-y*z+z*z-z*w+w*w
    v = x*y-x*z-x*w+y*z-y*w+z*w
    return u, v, u*u+u*v-v*v, 2*u+v, 3*u-v


def independent_inspect(a):
    square = mul(a, galois(a, 4))
    u, v = square[0], -square[2]
    require(square == (u, 0, -v, -v), ('real coordinates', a))
    s0 = rational(add(square, galois(square, 2)), 'S0')
    ja = mul(J, a)
    jsquare = mul(ja, galois(ja, 4))
    s1 = rational(add(jsquare, galois(jsquare, 2)), 'S1')
    return u, v, ring_norm(a), s0, s1


def lambda_mul(a):
    x, y, z, w = a
    return x+w, y-x+w, z-y+w, 2*w-z


def lambda_divide(a):
    require(sum(a) % 5 == 0, ('not lambda divisible', a))
    t = sum(a)//5
    out = (a[0]-t, a[0]+a[1]-2*t, a[0]+a[1]+a[2]-3*t, t)
    require(lambda_mul(out) == a, ('lambda division inverse', a))
    return out


def digits(a, k):
    q = a
    result = []
    for _ in range(k):
        r = sum(q) % 5
        result.append(r)
        q = lambda_divide(subtract(q, (r, 0, 0, 0)))
    return tuple(result), q


def matmul(a, b):
    return tuple(tuple(sum(a[i][r]*b[r][j] for r in range(4))
                       for j in range(4)) for i in range(4))


def matvec(a, x):
    return tuple(sum(row[j]*x[j] for j in range(4)) for row in a)


IDENTITY = tuple(tuple(int(i == j) for j in range(4)) for i in range(4))


def inverse_and_det(matrix):
    a = [[Fraction(x) for x in row]+[Fraction(x) for x in IDENTITY[i]]
         for i, row in enumerate(matrix)]
    determinant = Fraction(1)
    for col in range(4):
        pivot = next((r for r in range(col, 4) if a[r][col]), None)
        require(pivot is not None, 'singular lattice matrix')
        if pivot != col:
            a[col], a[pivot] = a[pivot], a[col]
            determinant = -determinant
        value = a[col][col]
        determinant *= value
        a[col] = [x/value for x in a[col]]
        for r in range(4):
            if r != col:
                value = a[r][col]
                a[r] = [x-value*y for x, y in zip(a[r], a[col])]
    return tuple(tuple(row[4:]) for row in a), determinant


def lattices():
    basis = [tuple(int(i == j) for i in range(4)) for j in range(4)]
    columns = [mul(LAM, b) for b in basis]
    matrix = tuple(tuple(columns[j][i] for j in range(4)) for i in range(4))
    current = IDENTITY
    out = {}
    for k in range(1, 9):
        current = matmul(matrix, current)
        inv, determinant = inverse_and_det(current)
        require(determinant == 5**k, ('lattice determinant', k, determinant))
        require(matmul(current, inv) == matmul(inv, current) == IDENTITY,
                ('lattice inverse identities', k))
        scaled = tuple(tuple(x*5**k for x in row) for row in inv)
        require(all(x.denominator == 1 for row in scaled for x in row),
                ('integral adjugate', k))
        numerator = tuple(tuple(int(x) for x in row) for row in scaled)
        out[k] = (current, numerator, 5**k)
    return out


def quotient_if_member(delta, lattice):
    matrix, numerator, denominator = lattice
    values = matvec(numerator, delta)
    if any(x % denominator for x in values):
        return None
    quotient = tuple(x//denominator for x in values)
    require(matvec(matrix, quotient) == delta, 'lattice quotient reconstruction')
    return quotient


def check_sources(source_root):
    pin = json.loads((ROOT/'PIN.json').read_text(encoding='utf-8'))
    for name, row in pin['files'].items():
        raw = (ROOT/name).read_bytes()
        require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'],
                ('local immutable input', name))
    manifest = json.loads((ROOT/'SOURCE.json').read_text(encoding='utf-8'))
    require(manifest['public_commit'] == '5e872c22a18043c8126945a982efad55472cea82',
            'public source identity')
    for name, row in manifest['files'].items():
        raw = (source_root/name).read_bytes()
        require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'],
                ('public source bytes', name))
    return manifest['public_commit']


def build_witness(pair, k, facts, residue, lattice):
    if pair is None:
        return None
    left, right = pair
    delta = subtract(right, left)
    valuation = next(i for i in range(8) if residue[left][i] != residue[right][i])
    q = delta
    for _ in range(k):
        q = lambda_divide(q)
    independent_q = quotient_if_member(delta, lattice)
    require(q == independent_q, ('witness quotient comparison', k, pair))
    u, v, n, s0, s1 = facts[left]
    require(facts[left] == facts[right], ('witness equal traces', pair))
    return {'left': left, 'right': right, 'u': u, 'v': v, 'norm': n,
            'traces': [s0, s1], 'residue_digits': residue[left][:k],
            'difference': delta, 'difference_norm': ring_norm(delta),
            'lambda_valuation': valuation, 'division_quotient': q,
            'lattice_quotient': independent_q,
            'first_separating_digits': {'depth': valuation+1,
                'left': residue[left][valuation], 'right': residue[right][valuation]}}


def run():
    require(not sys.flags.optimize, 'Python optimization forbidden')
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'output directory already exists')
    source_commit = check_sources(args.source_root)
    require(mul(J, JI) == mul(JI, J) == ONE, 'J unit identity')
    basis = [tuple(int(i == j) for i in range(4)) for j in range(4)]
    for e in basis:
        require(lambda_mul(e) == mul(LAM, e), 'independent lambda multiplication')
        require(inspect(e)[:3] == (1, 0, 1), 'included lower strip endpoint')
        require(inspect(mul(JI, e))[:3] == (1, 1, 1), 'excluded upper strip endpoint')
    require(ring_norm(LAM) == 5 and 5**6 > 16*941, 'norm separation premises')
    lattice = lattices()
    facts = {}
    scanned = 0
    for alpha in product(range(-8, 9), repeat=4):
        scanned += 1
        u, v, n, s0, s1 = inspect(alpha)
        require((0 <= v < u) == (2*s0 < 3*s1 and 2*s1 <= 3*s0),
                ('strip endpoint equality', alpha))
        if 0 <= v < u and 1 <= n <= 941:
            require(inspect(alpha) == independent_inspect(alpha), ('ring crosscheck', alpha))
            require(s0 <= 92 and all(5*x*x <= 4*s0 for x in alpha), 'coefficient bound')
            facts[alpha] = (u, v, n, s0, s1)
    strip = sorted(facts)
    require(scanned == 17**4 and len(strip) == 3150, ('strip size anchor', scanned, len(strip)))
    require(digest(strip) == STRIP_DIGEST, ('complete original strip digest', digest(strip)))
    require(sum(facts[a][2] <= 940 for a in strip) == 3110, 'norm940 anchor')
    traces = defaultdict(list)
    residue = {}
    groups = {k: defaultdict(list) for k in range(1, 9)}
    for alpha in strip:
        traces[facts[alpha][3:]].append(alpha)
        residue[alpha] = digits(alpha, 8)[0]
        for k in range(1, 9):
            ds, q = digits(alpha, k)
            require(ds == residue[alpha][:k], 'residue prefix consistency')
            representative = ZERO
            for i, r in enumerate(ds):
                representative = add(representative, tuple(r*x for x in power(LAM, i)))
            delta = subtract(alpha, representative)
            require(mul(power(LAM, k), q) == delta, 'exact digit reconstruction')
            require(quotient_if_member(delta, lattice[k]) == q, 'independent digit representative')
            groups[k][facts[alpha][3:]+ds].append(alpha)
    require(len(traces) == 145, ('trace class anchor', len(traces)))
    direct5 = {facts[a][3:]+tuple(x % 5 for x in a) for a in strip}
    direct25 = {facts[a][3:]+tuple(x % 25 for x in a) for a in strip}
    require(len(groups[4]) == len(direct5) == 2603, 'STOP mod5/k4 anchor')
    require(len(groups[8]) == len(direct25) == 3150, 'STOP mod25/k8 anchor')
    pair_total = 0
    valuation_histogram = Counter()
    valuation_first = {}
    collisions = {k: [] for k in range(1, 9)}
    for trace, members in sorted(traces.items()):
        for left, right in combinations(members, 2):
            pair_total += 1
            delta = subtract(right, left)
            nd = ring_norm(delta)
            require(0 < nd <= 16*facts[left][2], 'equal-trace difference norm bound')
            valuation = next((i for i in range(8) if residue[left][i] != residue[right][i]), 8)
            require(valuation < 8, 'STOP distinct strip pair collides at k8')
            valuation_histogram[valuation] += 1
            pair = (left, right)
            valuation_first.setdefault(valuation, pair)
            valuation_first[valuation] = min(valuation_first[valuation], pair)
            for k in range(1, 9):
                same = residue[left][:k] == residue[right][:k]
                q = quotient_if_member(delta, lattice[k])
                require(same == (q is not None), ('independent ideal equivalence', k, pair))
                require(same == (k <= valuation), 'valuation prefix identity')
                if same:
                    require(nd % (5**k) == 0, 'ideal norm divisibility')
                    collisions[k].append(pair)
                if k in (4, 8):
                    modulus = 5 if k == 4 else 25
                    require(same == all(x % modulus == 0 for x in delta),
                            ('rational ideal equivalence', k, pair))
    rows = []
    partitions = {}
    for k in range(1, 9):
        fibres = [{'key': key, 'members': values} for key, values in sorted(groups[k].items())]
        partitions[str(k)] = fibres
        count = len(fibres)
        require(sum(len(f['members'])*(len(f['members'])-1)//2 for f in fibres)
                == len(collisions[k]), 'complete collision pair count')
        lex_pair = min(collisions[k]) if collisions[k] else None
        norm_pair = min(collisions[k], key=lambda p: (facts[p[0]][2], p[0], p[1])) if collisions[k] else None
        rows.append({'depth': k, 'key_count': count, 'usable_native_labels': min(3125, count),
            'native_shortfall': max(0, 3125-count), 'injective': count == len(strip),
            'collision_fibres': sum(len(f['members']) > 1 for f in fibres),
            'largest_fibre': max(len(f['members']) for f in fibres),
            'fibre_size_histogram': dict(sorted(Counter(len(f['members']) for f in fibres).items())),
            'collision_pairs': len(collisions[k]), 'complete_partition_sha256': digest(fibres),
            'lexicographic_pair': build_witness(lex_pair, k, facts, residue, lattice[k]),
            'least_norm_pair': build_witness(norm_pair, k, facts, residue, lattice[k])})
    counts = [row['key_count'] for row in rows]
    require(counts == sorted(counts), 'nested-ideal count monotonicity')
    require(counts[5:] == [3150, 3150, 3150], 'disclosed k>=6 norm-bound prediction')
    result = {'id': 'C-J-RAMIFIED-DECODER-DEPTH-N', 'version': 1,
        'status': 'PASS; NON-CANONICAL candidate-C finite census', 'source_commit': source_commit,
        'norm_bound': 941, 'scanned_box_vectors': scanned, 'strip_count': len(strip),
        'strip_sha256': digest(strip), 'trace_classes': len(traces),
        'same_trace_unordered_pairs_checked': pair_total,
        'independent_matrix_pair_tests': 8*pair_total,
        'first_depth_for_3125': next((r['depth'] for r in rows if r['key_count'] >= 3125), None),
        'first_injective_depth': next((r['depth'] for r in rows if r['injective']), None),
        'depths': rows}
    pair_data = {'all_same_trace_pairs': pair_total, 'lambda_valuation_histogram': dict(sorted(valuation_histogram.items())),
                 'lexicographic_first_pair_per_valuation': dict(sorted(valuation_first.items())),
                 'maximum_valuation': max(valuation_histogram)}
    args.output.mkdir(parents=True, exist_ok=False)
    output_manifest = {}
    for name, data in [('STRIP.json', strip), ('KEYS.json', partitions), ('CENSUS.json', result),
                       ('PAIR_VALUATIONS.json', pair_data)]:
        raw = (json.dumps(data, sort_keys=True, indent=2, ensure_ascii=True)+'\n').encode('utf-8')
        (args.output/name).write_bytes(raw)
        output_manifest[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    (args.output/'MANIFEST.json').write_bytes((json.dumps(output_manifest, sort_keys=True, indent=2)+'\n').encode())
    print(compact({'result': result, 'pair_valuations': pair_data, 'outputs': output_manifest}))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', newline='\n')
    run()

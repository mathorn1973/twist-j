# Packaging correction

The first administrative manifest generator excluded every file named SHA256SUMS, although three lane-level manifests must be included. The integrity checker correctly rejected that incomplete inventory before any ZIP was written. The unsealed first manifest is preserved as PACKAGING-MANIFEST-ATTEMPT-1.txt. The corrected generator excludes only the top-level manifest itself. No scientific contract, verifier, output, proof or candidate decision changed, and no scientific program was rerun.

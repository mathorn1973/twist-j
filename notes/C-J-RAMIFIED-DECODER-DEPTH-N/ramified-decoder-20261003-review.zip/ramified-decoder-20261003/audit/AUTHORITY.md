# Authority and local execution scope

Local audit begun 2026-10-03 and continued after midnight in Europe/Prague on 2026-10-04. Directory naming preserves the start date. NON-CANONICAL.

The newly supplied six-lane assignment was read in full. Its explicit permission for exact local computation after a scope/verifier freeze applies here. This differs from the stricter initial carrier-preparation task. No public formal probe was started. The requested review of #1346 is local and does not reopen its issue.

| Authority field | Verified value |
| --- | --- |
| Repository / branch | mathorn1973/twist-j / main |
| Fresh live main | 5e872c22a18043c8126945a982efad55472cea82 |
| Main tree | 620670f52323e68861a1be3fd4817f385c13a834 |
| State / Canon | ACTIVE / Public Canon v97 |
| Content commit | 82ecf0aac0ee79c947000968e71573d4c65d386d |
| Annotated canon-v97 tag object | 163f34ec4f033c093807f794ccde6f6566dcdabb |
| Peeled tag target | 738e0421bd15aaea5bb6ef2a56f1cab752d44de5 |
| CANON.md SHA-256 | 257f83a386aad7d309f7017bd719b6212e3cffea60e4986caa5169d6543f108d |
| CANON.md byte count | 897762 |

STATUS was read before scientific work; POLICY, AGENTS, CORE, FRONTIER and relevant REGISTRY/GATES rows were read. The source checkout is `.codex-worktrees/native-carrier-clock-prep`, detached at the exact main above. It is a separate public science repository, not the outer website repository. Existing unrelated website edits were preserved.

The source identity was freshly read for this assignment. The repository's static `python tools/check_canon.py` was rerun and returned `CANON PASS v97 claims=492`, exit 0. It checks all five normative hashes. Prior verified ancestry remains applicable to the identical object IDs: content commit -> canon-v97 -> current main; the canon directory has no tag-to-main diff.

The existing [main CI run 37136085427](https://github.com/mathorn1973/twist-j/actions/runs/37136085427) was freshly read back at this exact head: architecture-aarch64 (111240788358), architecture-x86_64 (111240788454), and aggregate check (111240853818) all succeeded. Publication was skipped for ordinary main. These checks validate the public baseline; they are not new candidate run evidence.

The refreshed collision release is [COLLISIONS.md](COLLISIONS.md), with exact inherited scope and live-delta evidence. The prior full authority and collision audit remains accessible at `../../native-carrier-clock-20261003/audit/`; it is evidence continuity, not a substitute for the fresh main and delta reads.

Each computational lane owns its pre-run contract, accepted verifier SHA, actual stdout/stderr and execution record. One-architecture counts are at most candidate-C. Proof-only theorems may be candidate-T with complete proofs. Neither local hashes nor two separately written programs substitute for public Git pinning and the repository's formal two-architecture gate. No new GitHub content, Canon, registry, tag, release or workflow was changed.

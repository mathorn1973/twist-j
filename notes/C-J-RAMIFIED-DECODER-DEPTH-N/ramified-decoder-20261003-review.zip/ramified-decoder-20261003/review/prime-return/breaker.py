"""Independent local review audit; see the frozen PREREG.md. Integers only."""
from itertools import product
from math import gcd, lcm, prod


def multiply(a, b):
    e = len(a)
    return tuple(sum(a[k] * b[n-k] for k in range(n+1)) % 5 for n in range(e))


def powers(a, limit):
    one = (1,) + (0,) * (len(a)-1)
    values = [one]
    for _ in range(limit):
        values.append(multiply(values[-1], a))
    return values


def ramified():
    checks = 0
    for e in range(1, 5):
        j_unit = tuple(([2, -2, 1, 0][k]) % 5 for k in range(e))
        orbit = powers(j_unit, 20)
        unit_order = next((h for h in range(1, 21) if orbit[h] == orbit[0]), None)
        assert unit_order == (4 if e == 1 else 20), (e, unit_order)
        for alpha in product(range(5), repeat=e):
            v = next((i for i, a in enumerate(alpha) if a), e)
            expected = 1 if v == e else (4 if e-v == 1 else 20)
            for h, element in enumerate(orbit):
                assert (multiply(alpha, element) == alpha) == (h % expected == 0), (e, alpha, h)
                checks += 1
        print(f"RAMIFIED e={e}: unit order {unit_order}; every alpha and h=0..20 PASS")
    eps = (0, 1)
    values = powers((2, 3), 20)
    assert values[4] != values[0] and multiply(eps, values[4]) == eps
    print("NONUNIT BOUNDARY: e=2, alpha=t, h=4 returns alpha; J itself does not return PASS")
    return checks


def oriented():
    j = 3
    assert sum(pow(j, k, 11) for k in range(5)) % 11 == 0
    assert next(k for k in range(1, 11) if pow(j, k, 11) == 1) == 5
    unit = (1+j*j) % 11
    assert unit == 10
    assert next(k for k in range(1, 11) if pow(unit, k, 11) == 1) == 2
    print("ORIENTED p=11, j=3: order(j)=5; J=-1; order(J)=2 PASS")


def clocks():
    families = [(r, s) for r in range(1, 9) for s in range(1, 9)] + [(4, 6, 8)]
    checks = 0
    for periods in families:
        length = lcm(*periods)
        image = {tuple(n % r for r in periods) for n in range(length)}
        assert len(image) == length and prod(periods) % length == 0
        admitted = 0
        for phase in product(*(range(r) for r in periods)):
            compatible = all((phase[i]-phase[j]) % gcd(periods[i], periods[j]) == 0
                             for i in range(len(periods)) for j in range(i))
            assert (phase in image) == compatible, (periods, phase)
            admitted += compatible
            checks += 1
        assert admitted == length
    print(f"CLOCKS: {len(families)} fixed families, {checks} phase tuples, compatibility and cardinality PASS")


def main():
    count = ramified()
    oriented()
    clocks()
    print(f"RETURN comparisons: {count}")
    print("PASS: finite local independent audit; infinite claims require the written proof")


if __name__ == '__main__':
    main()

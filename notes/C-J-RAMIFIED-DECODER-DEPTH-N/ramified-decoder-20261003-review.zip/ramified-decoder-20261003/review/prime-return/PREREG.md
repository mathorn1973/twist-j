# Independent local review plan: #1346 prime-return compatibility

2026-10-03. REVIEW-C-J-PRIME-RETURN-COMPATIBILITY-N, not a new claim and
not a reopening of #1346. NON-CANONICAL L1 incubation; no public write.

Source authority: mathorn1973/twist-j main
`5e872c22a18043c8126945a982efad55472cea82`, Canon v97. The coordinator
has verified unchanged main and authority/hash/check gates. The frozen
claim and original finite preregistration are issue #1346; its body is
retained without code in SOURCE-ISSUE-1346.json. The author's reported
proof-note blob is 3bed7c0ddb913134ee1e75323772788f2540c80b. This review
does not open that author's verify.py or import any author implementation.

## Independence and exposure

The reviewer already saw #1346's claim, freeze metadata, method description
and reported outcome table while auditing earlier collisions. Those are
exposed targets, not blind predictions. The original verify.py source has
never been read by this reviewer. No original program will be opened or
executed during this review. Own proof reasoning and boundary targets were
developed before this plan; no new scientific program has yet been run.
Repository text searches, hashes and API reads were administrative only.

The new checker uses truncated lambda-adic polynomial rings and finite
integer congruence orbits, not the original author's paired j-basis and
J-companion implementations. It is independently authored by this reviewer,
with known outcomes disclosed. This is not an external referee or blind
independent outcome confirmation.

## Frozen mathematical carrier and questions

Let O=Z[j], Phi5(j)=0, j primitive of order5, J=1+j^2 and lambda=1-j.
For nonzero proper ideals I and nonnegative n, use unit order
r_I=ord_(O/I)^*(J), and for a finite nonempty family use L=lcm(r_i).
Native state is the unchanged (n,psi) with n in N0 and one native update
incrementing n by1. Equality of complete readings is literal.

Independently prove or reject the six source claims: invariance of the
principal ideal of nonzero alpha under every integer J power; exact unit
return multiples; joint-image cardinality and pairwise gcd compatibility;
rational-modulus factor5 with oriented-prime boundary; source-blind complete
all-rational-prime counter reading and unbounded orders; minimal L-state
autonomous emitter and unrestricted external-prime blindness versus the
different norm-bounded two-trace/mod25 interface. Supporting normalized lag
and gcd-of-return-ideals identities will be checked by algebra.

Mandatory nonunit qualification: a return of J^h itself is not automatically
the return period of J^h alpha when alpha is a nonunit modulo I. Derive the
correct colon-ideal condition, including alpha in I, and give an exact
nonzero-residue nonunit counterexample to the tempting stronger statement.
Do not attribute that stronger statement to #1346 if it is absent there.

## Own finite breaker: frozen scope before execution

CODE: own `breaker.py`, Python standard library, integers only; exact bytes
and SHA-256 are recorded in FREEZE.json before its first execution.

CARRIER:

1. For e=1,2,3,4, A_e=F5[t]/(t^e), exactly represented by e coefficient
   tuples. This matches O/(lambda^e) through t=lambda; the ring equivalence
   is a proof obligation, not inferred from matching counts. J=2-2t+t^2
   reduced at that depth. Test all 5^e alpha and h=0,...,20.
2. Unit-return anchors: order(J)=4 at e=1 and20 at e=2,3,4. For nonzero
   alpha of t-adic valuation v<e, test return iff r_(e-v) divides h.
   For alpha=0, every h returns. Mandatory e=2, alpha=t, h=4 witness.
3. One oriented prime above11, evaluation j=3 in F11. Check Phi5(3)=0,
   order(j)=5, J=-1 and order(J)=2. This is an existing canonical boundary,
   not a new result or search over all split primes.
4. All ordered pairs r,s in1,...,8 and all phase pairs; additionally the
   entire phase product for (4,6,8). Compare explicit n=0,...,L-1 orbit
   membership with all pairwise gcd compatibility equations, and check
   image size L and product/L index. This tests integer clock algebra,
   not a claim that every such period arises from a chosen ideal.

SYSTEMATICS: no floating point, random numbers, network, imported source,
target-dependent search extension or parameter change. Multiplication is
truncated convolution modulo5. Order loops stop at20 for these frozen
ramified anchors and at10 for the specified F11 unit; absence by the bound
is failure. The ring/order and congruence tests are finite proof audits,
not evidence for infinite quantifiers by extrapolation.

FALSIFIERS: any exact ring anchor, return equivalence, required counterexample,
orbit count or compatibility mismatch stops the checker with nonzero exit.
No tolerance. A syntax/environment failure is distinguished from a false
mathematical claim, preserved as such, and never relabelled a passing run.

DECISION: ACCEPT only when the independently written proof establishes
each literal claim under its stated quantifiers. NEEDS-NARROWING for a
missing hypothesis in the actual source claim; REJECT for an exact source-
scope contradiction. Counterexamples to explicitly excluded stronger
claims are boundaries, not rejection of #1346. The finite audit can earn
at most candidate-C; complete proofs can justify candidate-T only at their
stated L1 scope. No physical, preparation, energy, occurrence, apparatus,
decoder-selection or L2-L6 conclusion.

## Execution and custody

After this plan and complete checker have a local hash freeze, one isolated
Python3.12 local execution is authorized by the user's new task. It is not
a public or formal gate and is not two-architecture evidence. Save raw
stdout/stderr and actual exit/environment only after execution; do not
manufacture EXPECTED.txt. Preserve immutable source bytes and any failure.
All-prime injectivity, unbounded order and ideal CRT remain proof obligations
regardless of the finite result. No old verifier or sealed probe is run.

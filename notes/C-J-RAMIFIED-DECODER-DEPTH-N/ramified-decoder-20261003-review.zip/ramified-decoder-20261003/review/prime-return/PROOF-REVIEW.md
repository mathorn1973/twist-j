# Independent review of #1346: prime-return compatibility

**Verdict: ACCEPT the six literal mathematical claims of #1346, with the
source's stated carriers and exclusions.** In particular, the return claim
is about `J^h-1 in I`. It must not be paraphrased as the same period for
every nonunit source alpha modulo I. The explicit boundary below rejects
that stronger paraphrase, not the actual issue statement.

Completed 2026-10-04 Europe/Prague (2026-10-03 UTC). NON-CANONICAL, L1.
The written arguments establish the stated conditional arithmetic results
at candidate-T level; the new finite audit is at most candidate-C. No
Canon row, ownership, public probe, physical interpretation or formal gate
is created. This is an independent derivation and independently authored
local checker with **exposed statements and outcomes**, not a blind test.

## 1. Reviewed source and independence custody

Public authority/context is main
`5e872c22a18043c8126945a982efad55472cea82`, Public Canon v97. The
coordinator separately verified authority, hashes and checks. The source
statement and preregistration are the complete issue #1346 body retained
in `SOURCE-ISSUE-1346.json`, SHA-256
`dda32e9d182d4eb848061c86688b5710b52795a048d6d12de92e6337bf8408c8`.
The reported author note blob is
`3bed7c0ddb913134ee1e75323772788f2540c80b`, reported note SHA-256
`1fcb76de21eae6ee1e6d83f8492bc7f7de259316f4c73adc782164f8efc1017c`.
The review concerns the issue's actual text, not an assertion that the
reported author's full program or proof-note bytes were independently read.

Before this review the reviewer had seen #1346's statement, code-method
description, source-freeze metadata and final reported outcome table in a
collision audit. **Original verify.py was never read, imported or executed.**
The new implementation uses truncated lambda polynomial rings and direct
integer phase orbits, not the original author's j-basis/J-companion code.

Own PREREG.md SHA-256:
`b01be86e767c33312ddfb175c20fd21c43c74062400ddafcce12ea9ef3c2660e`.
Own breaker.py SHA-256:
`be0f19cec7dff486dfe3e3cf8867a7cdfe229d2f4b9f5eaa86a1e28596af0eb7`.
Both complete sources were frozen in FREEZE.json at
2026-10-03T22:02:08.6090221Z before first execution. No old probe or
original verifier was rerun, and no GitHub content was modified.

## 2. Unit, principal ideals and lag ideals

Let O=Z[j], Phi5(j)=0 with j primitive, and J=1+j^2. Put t=j+j^-1.
Then `t^2+t=1` by the cyclotomic relation, so t is an integral unit with
inverse t+1. Since `J=j*t`, J is a unit. This proves, for every nonzero
alpha in O and every integer n,

```text
(J^n alpha)=(alpha).
```

Every prime-ideal valuation is therefore unchanged. In particular this
identity includes negative n and sources that are nonunits in O. For
every integer n and h>=1 the fractional ideal normalization gives

```text
(J^(n+h)alpha-J^n alpha) (alpha)^(-1)
  = (J^n) (J^h-1) = (J^h-1).
```

Nonzero alpha is needed for its inverse fractional ideal. Cancellation
here takes place in the fractional-ideal group, not inside a residue ring.

J has infinite multiplicative order: in the principal complex embedding,
t=(sqrt5-1)/2 lies strictly between0 and1 and |j|=1, so |J|=t<1. No
positive J power equals1. This also follows from the existing canonical
J-PROJECTIONS [T], but the displayed unit calculation is independent.

## 3. Unit-return period and the nonunit boundary

For any nonzero proper ideal I, O/I is a finite nonzero ring: choose
nonzero a in I; multiplication by a on the rank-four integer lattice has
nonzero determinant, so O/(a) is finite and surjects onto O/I. The image
of J is a unit. Its finite group order r_I is therefore well defined and
positive. The group-order criterion gives, for every integer h,

```text
J^h-1 in I  iff  r_I divides h.
```

Thus every prime-ideal power is reached by this return-ideal condition at
some positive lag. This does not say a J orbit changes its source ideal.
For positive a,b, Euclidean subtraction

```text
(J^a-1)-J^(a-b)(J^b-1)=J^(a-b)-1     (a>=b)
```

preserves the generated ideal. The integer Euclidean algorithm consequently
proves `(J^a-1)+(J^b-1)=(J^gcd(a,b)-1)`. This is equality of ideals, not
a claimed equality of greatest common divisors of scalar norms.

For an actual source alpha, its return condition is instead exactly

```text
J^h alpha = alpha modulo I
  iff J^h-1 in (I:alpha),
(I:alpha)={x in O : x alpha in I}.
```

If alpha is a unit modulo I, `(I:alpha)=I`, recovering r_I. If alpha is
in I, every lag returns its zero residue. Generally the period is the
order of J modulo `(I:alpha)`, assigning period1 when that ideal is O.
Equivalently, for integral alpha and I=product P^e_P, the colon ideal has
exponents `max(e_P-v_P(alpha),0)`. No cancellation of a nonunit residue is
permitted.

**Nonzero-residue counterexample to the stronger paraphrase:** take
I=(lambda^2), lambda=1-j, and alpha=lambda. As proved below, O/I is
F5[lambda]/lambda^2 and J=2-2lambda there. Its unit order is20, while
J^4=1+lambda, so `J^4 alpha=alpha` but `J^4!=1 modulo I`. In fact the
alpha orbit has period4: multiplication on lambda's nonzero residue line
is by the scalar2. Depth two is the first ramified depth admitting a
nonzero nonunit residue; depth one is a field. This does not falsify #1346,
whose frozen return statement explicitly uses d_h=J^h-1.

## 4. Joint clocks and the distinction from ring CRT

Take any finite nonempty family of nonzero proper ideals I_1,...,I_s,
periods r_i, and L=lcm(r_i). Each residue J^n modulo I_i is equivalent
to the phase n modulo r_i: by the order definition two powers agree
exactly when their exponent difference is divisible by r_i.

The homomorphism from Z to the product of Z/r_i has kernel LZ, so its
image has exactly L elements, all already attained for n=0,...,L-1.
For phases k_i modulo r_i, necessity of

```text
k_i = k_j modulo gcd(r_i,r_j)    for every pair i,j
```

is immediate. For sufficiency, for each rational prime ell dividing L,
choose an index with maximal ell-adic valuation of r_i. Its k_i fixes one
residue modulo that maximal prime power. Pairwise compatibility makes
this residue agree with every other k_j modulo the ell-part of r_j.
Ordinary CRT over these mutually coprime maximal prime powers produces n
modulo L satisfying every requested phase. This proves the complete
criterion and the product-index `product(r_i)/L` without a probability
assumption.

Pairwise coprime ideals do identify the entire quotient ring with a
product of quotient rings. That does not make the orbit of the *single*
element J fill a Cartesian product of its cycles. Those cycles fill the
product exactly when their periods are pairwise coprime. Ring CRT and
independence of one cyclic orbit are different statements.

## 5. Rational moduli, ramified five and oriented primes

For a rational integer m>=2 the ideal mO is conjugation-stable. Also j
has exact order5 modulo mO: for k=1,2,3 the coefficients of j^k-1 in
the integral basis contain1, and for k=4 use
`j^4-1=-2-j-j^2-j^3`; none can be divisible by m. Since
`J/conjugate(J)=j^2`, a unit return J^h=1 modulo mO implies the same
return for conjugate(J), hence j^(2h)=1 and 5 divides h.

This independently proves the factor5 used in #1346, in agreement with
canonical J-RESIDUE-PERIOD [T]. For s such rational moduli, if e_i=v5(r_i)
then every e_i>=1 and

```text
v5(product(r_i)/L)=sum e_i-max e_i >= s-1.
```

Other common period factors may occur too; nothing asserts that five is
the only source of compatibility constraints.

The ramified boundary is particularly transparent. With lambda=1-j,

```text
Phi5(1-lambda)=lambda^4+5(1-2lambda+2lambda^2-lambda^3).
```

For e<=4 the polynomial in parentheses is a unit modulo lambda^e,
because its constant term is1 and its remaining part is nilpotent. Thus
the ideals `(lambda^e,Phi5(1-lambda))` and `(lambda^e,5)` in Z[lambda]
coincide. This proves, rather than infers by counting,

```text
O/(lambda^e) = F5[lambda]/(lambda^e),        1<=e<=4.
```

In particular `(5)=(lambda^4)` (also canonical C20-TEICHMULLER-SPLIT).
Here J=2-2lambda+lambda^2. In characteristic5, J^5=2 modulo lambda^4,
so J^20=1. At depth one its order is4. At every depth2 through4, J^4
has coefficient1 on lambda and is not1; combined with reduction modulo
lambda this makes its order exactly20. Consequently the rational ideal
(5) has order20 but its unique prime ideal (lambda) has order4. Applying
the rational-modulus factor5 to a prime ideal would already fail here.

At a split prime, choose P=(11,j-3). The element3 has exact order5 in
F11 and satisfies Phi5(3)=0; J maps to1+3^2=-1, of order2. This is the
existing J-RESIDUE-COLLAPSE-FIVE [T] witness, not a new discovery. A
single oriented prime ideal is not conjugation-stable in the required
way. #1346 expressly confines its factor5 assertion to rational moduli.

## 6. The complete prime family reads precisely the native counter

Define H_p(n,psi)=J^n modulo pO for every rational prime p. The actual
native update increments n by1, so `H_p(U(n,psi))=J H_p(n,psi)` regardless
of the checkpoint update. Every H_p is independent of psi.

Suppose all H_p values agree for counters n,m. Then J^n-J^m is in pO
for every rational prime. Each of its four integral basis coefficients
is divisible by every prime, hence zero. Thus J^(n-m)=1, and J's infinite
order implies n=m. Conversely equal counters plainly give equal values
for every prime and every psi. The complete family's fibres on Omega are
therefore exactly the equal-counter fibres.

The orders over rational primes are unbounded. Otherwise they would all
be at most B for some finite B. With L=lcm(1,...,B), J^L-1 would then be
in pO for every prime, so zero by the same coefficient argument, contrary
to infinite order. This argument is universal; finite prime censuses do
not prove it.

The family faithfully recodes the counter and loses all checkpoint/source
distinctions at the same counter. This is a claim about these particular
functions H_p, not about every prime/residue reading with a separately
supplied source codeword. No physical clock or persistent record is proved.

## 7. Minimal finite autonomous emitter

For the finite family in section4, require an autonomous deterministic
machine with an initial state, fixed state update and fixed state-only
output map emitting the full phase tuple at every n>=0. Its first L
outputs are pairwise distinct. Equal machine states would have equal
outputs, so at least L distinct states are necessary. The cycle Z/L with
update n->n+1 and output its residues provides exactly L states, proving
attainability.

This counts the complete machine: an uncounted external clock, time-indexed
readout, supplied word or controller changes the class. The all-prime
family has pairwise distinct outputs for all n, so no finite state set can
emit it through one fixed state-only map. The unbounded native counter is
already a permitted resource and is not excluded by this finite-state
statement. Exact aperiodicity of a driven finite checkpoint is not the
same as an autonomous finite emitter.

## 8. External-prime blindness and the mod25 inverse

For M>=1 and a prime ideal P coprime to MO, CRT allows, for every fixed
residue a modulo MO, integral alpha,beta satisfying

```text
alpha = beta = a modulo MO,
alpha = 0 modulo P,        beta = 1 modulo P.
```

Both can be chosen nonzero by adding a nonzero element of MO intersect P
if necessary. Thus one unrestricted residue modulo MO cannot determine
P-divisibility. This does not guarantee any norm bound or equal extra
observables for the chosen alpha,beta.

The canonical J-TWO-TRACE-RESIDUE-INVERSE [T] instead observes
`D_25(alpha)=(S(alpha),S(J alpha),alpha mod25O)` on nonzero inputs with
N(alpha)<=941. It retains **two additional unbounded integer traces** and
a norm restriction, and the exact inverse reconstructs alpha. Once alpha
is recovered, its ideal divisibility can of course be decided. Nor does
the scalar-capacity theorem concern the source-blind family J^n alone:
J-OBSERVED-SCALAR-CODE-CAPACITY [T] fixes a selected source codebook and
its own no-separately-supplied-counter observation class.

The known 2603/3150 D5/D25 capacities and full-depth sufficiency are cited
at their current canonical status, not recomputed here. Neither #1346 nor
this review resolves the new partial lambda-depth census. There is no
contradiction between the residue-only unrestricted CRT obstruction and
the bounded, two-trace decoder.

## 9. Actual local breaker result and limits

The frozen new checker ran once at 2026-10-03T22:02:53.641292Z on Windows11,
AMD64, Python3.12.10, command `python -I -X utf8 breaker.py`. Exit0;
stderr0 bytes. Raw stdout562 bytes, SHA-256
`550f5ef1aa7d390a4f45fe9ee5bc4638e85708a71c71db1925ec700c24380eab`.
RUN.json records timing, frozen source hashes and raw output custody.

The run checked all780 residues across depths1 through4 at every h=0..20
(16,380 exact return comparisons), the specified oriented-prime witness,
and1,488 phase tuples in65 fixed period families. Every frozen check
passed. The nonunit example is a successful negative control against the
stronger invalid paraphrase, not a fired falsifier of #1346.

This is one local architecture, independent code with known targets, and
finite candidate-C evidence only. The universal conclusions above rest on
the written proofs. No EXPECTED.txt, formal/public gate or blind-test
description has been manufactured. The source claim, sealed probes and
old verifiers remain unchanged.

## 10. Final disposition

ACCEPT #1346 as written. Preserve explicitly: alpha!=0 in fractional-ideal
normalization; nonzero proper I for unit order; return of J itself versus
return of a nonunit source; finite nonempty joint families; rational mO
versus one prime ideal; fixed state-only autonomous output for the L-state
bound; and the exact source-blind nature of H_p. This result justifies no
physical direction, coupling, preparation, event/occurrence law, material
record, energy, codebook selection or L2-L6 lift. No old task is reopened
and no new scientific owner is claimed.

# The relative norm-one group of Q(zeta_5)

NON-CANONICAL. **Result: candidate-T**, complete L1 proof within
`CONTRACT.md`. No new scientific program was run. Write c(x)=bar(x),
K=Q(j), O=Z[j], and use the assignment's notation

    T(K)={x in K^*: x bar(x)=1}.

This is the group of elements satisfying the relative norm-one equation
for K/K^+=Q(sqrt5). It is not the absolute norm-one group defined by
N_(K/Q)(x)=1 in P-J-NORM-TRACE-TANGENT-SEAM-1.

**Theorem.** As an abstract abelian group,

    T(K) ~= mu_10 x direct_sum_(rational primes p=1 mod5) Z^2.

The valuation quotient is intrinsic. Writing it as the displayed copies
of Z^2 and choosing lifts uses prime-pair orientations and generators;
the displayed splitting is not claimed canonical. The integral subgroup
T(K) intersect O^* is exactly mu_10, the already registered kernel in
CM-ALTERNATING-PENCIL [T], P6.

**1. Rational primes and complex conjugation.** Since O=Z[j] is the full
ring of integers, for p!=5 the prime ideals over p correspond to the
irreducible factors of Phi_5 in F_p[X]. Its four roots are the nontrivial
fifth roots; they are distinct because p!=5. Frobenius sends j^a to j^(pa),
so each orbit has length ord_5(p). This proves the residue degrees and
prime counts below. Identifying Gal(K/Q) with (Z/5Z)^*, conjugation is
-1 and the decomposition group is <p>. A prime is stable under
conjugation exactly when -1 belongs to that subgroup.

| Rational prime | (e,f,g) | Conjugation on prime ideals | Antisymmetric valuation rank |
| --- | --- | --- | --- |
| p=1 mod5 | (1,1,4) | two exchanged pairs | 2 |
| p=4 mod5 | (1,2,2) | each prime individually stable | 0 |
| p=2 or 3 mod5 | (1,4,1) | the unique prime stable | 0 |
| p=5 | (4,1,1) | (lambda), lambda=1-j, stable | 0 |

For the last row, Phi_5(X)=(X-1)^4 modulo five gives the unique residue
prime (5,1-j), with residue field F5. The exact equality
(5)=(lambda)^4 and O/(lambda)=F5 is the registered ramification statement
of C20-TEICHMULLER-SPLIT [T]. Also bar(lambda)=-j^-1 lambda, explicitly
showing stability. In particular two primes over p=4 mod5 do not give a
conjugate pair: each is fixed by conjugation. This distinction is decisive.

**2. The valuation exact sequence.** Normalize v_P(P)=1, so for every
x in K^*, the fractional ideal (x) has the unique factorization

    (x)=product_P P^(v_P(x)),

with finitely many nonzero integer exponents. Conjugation gives
v_P(bar(x))=v_(bar(P))(x). Therefore x bar(x)=1 implies

    v_P(x)+v_(bar(P))(x)=0.

At a stable prime, this says 2v_P(x)=0 in Z and hence v_P(x)=0.
For every p=1 mod5 choose representatives P_(p,1),P_(p,2) of its two
conjugate pairs. The remaining exponents are their negatives. Thus

    v:T(K) -> A=direct_sum_(p=1 mod5) Z^2,
    v(x)=(v_(P_(p,1))(x),v_(P_(p,2))(x))_p

is a well-defined homomorphism. Its kernel consists exactly of relative
norm-one integral units: all valuations zero means (x)=O, hence x in O^*.
By the inherited exact unit structure O^*=mu_10 x <phi>, write
x=zeta phi^m. Its relative norm is phi^(2m). As phi>1 at the marked
principal embedding, this equals one exactly when m=0. Thus ker(v)=mu_10.
This also directly verifies the consumed kernel conclusion of
CM-ALTERNATING-PENCIL; that existing theorem retains ownership of it.

Class number one, inherited from CYCLOTOMIC-CLASS-NUMBER-ONE [T], makes
each chosen P_(p,i) principal. Choose pi_(p,i) in O generating it and set

    u_(p,i)=pi_(p,i)/bar(pi_(p,i)).

Then u_(p,i) bar(u_(p,i))=1 exactly, and its only nonzero valuations are
+1 at P_(p,i) and -1 at bar(P_(p,i)). These elements lift every standard
basis vector of A. Consequently v is surjective and the map

    s:A->T(K),  (n_(p,i))->product_(p,i) u_(p,i)^(n_(p,i))

is a homomorphism with v o s=identity. The product is finite by the direct
sum convention. Every x in T(K) has the unique form zeta*s(v(x)),
zeta in mu_10, because its quotient by s(v(x)) has zero valuations.
The intersection s(A) intersect mu_10 is trivial, proving the theorem.

Changing a chosen prime generator changes its ratio by a relative norm-one
unit; changing a prime-pair orientation inverts that free direction. The
valuation classification is unaffected. No relation is imposed between
the two conjugate pairs above one completely split rational prime.

**3. The exact p=11 witness.** Let alpha_r=1+2j^r, r=1,2,3,4. These are
the four Galois conjugates, and the polynomial identity

    product_(r=1)^4 (x+y j^r)=x^4-x^3y+x^2y^2-xy^3+y^4

gives

    N_(K/Q)(1+2j)=1-2+4-8+16=11.

The four nontrivial fifth roots in F11 are 5,4,3,9 in the order relevant
below. The following table follows from 1+2 rho_r^r=0 modulo eleven:

| r | rho_r | P_r=(alpha_r) |
| --- | --- | --- |
| 1 | 5 | (11,j-5) |
| 2 | 4 | (11,j-4) |
| 3 | 3 | (11,j-3) |
| 4 | 9 | (11,j-9) |

For example, 5^2=3, 5^3=4, 5^4=9 and 5^5=1 in F11. The displayed
evaluation ideals have quotient F11, hence norm eleven. Each contains
alpha_r, whose principal ideal also has norm eleven, so containment is
equality. Distinct roots make the four ideals distinct. Conjugation
exchanges P1 with P4 and P2 with P3. Their product is (11), in agreement
with the exact product of the four alpha_r being 11.

For

    u1=alpha_1/alpha_4,    u2=alpha_2/alpha_3,

the valuation vectors at (P1,P2,P3,P4) are

    v(u1)=(1,0,0,-1),     v(u2)=(0,1,-1,0).

Both have relative norm one. If u1^m u2^n lies in mu_10, its P1 and P2
valuations give m=n=0. This proves their independence modulo mu_10 purely
by exact valuations; it also proves each has infinite multiplicative order.

There are infinitely many p=1 mod5 without requiring a density theorem.
If their list were finite, let A be five times their product. A prime q
dividing Phi_5(A)>1 divides neither A nor five, and cannot divide A-1:
the last possibility would give q|Phi_5(1)=5. Thus A has exact order
five in F_q^*, so q=1 mod5. But every prime on the proposed list divides
A and hence does not divide Phi_5(A), a contradiction. Therefore the
displayed abstract free abelian part has infinite rank.

**4. What the powers of J contribute.** The inherited identity is

    J=phi^-1 j,    J bar(J)=phi^-2.

Thus J^n itself belongs to T(K) only for n=0. In the marked principal
complex embedding phi>0, its positive magnitude normalization is

    J^n/|J^n|=j^n.

Equivalently the algebraic scaling phi^n J^n=j^n gives only the finite
group mu_5. The ratio J^n/bar(J^n)=j^(2n) also has only five values.
No nonzero prime-ideal valuation is supplied: J and phi are units.

The positive-magnitude normalization is embedding-sensitive. Under
sigma_2:j->j^2, one has sigma_2(phi)=-phi^-1 and sigma_2(J)=-phi j^2,
so sigma_2(J)/|sigma_2(J)|=-j^2, of order ten. The marked algebraic
scaling still gives sigma_2(phi J)=j^2, but sigma_2(phi) is negative and
is not the inverse positive magnitude. Thus the five-phase statement is
for the specified principal normalization, not every positive-normalized
embedding. In every case these are finite root-of-unity phases and create
none of the free valuation directions above.

**Decision and boundary.** The proposed group isomorphism is correct,
with a noncanonical splitting and finite-support direct sum. New infinite
directions here mean multiplicative independence modulo mu_10, measured
by the two independent conjugate-prime pairs at each p=1 mod5. They are
not generated by J alone. This does not alter the real rapidity shell's
one-axis/two-orientations statement in #1346 or the existing
SPLIT-PRIME-RAPIDITY-CLASS. The abstract group has infinite rank, whereas
the corresponding relative algebraic torus over Q has finite dimension;
no dimension or topology is inferred from this rank. There is no physical
or electromagnetic interpretation, native implementation or decoder claim.
All frozen targets pass; no falsifier fired. Sources are in `SOURCES.tsv`.

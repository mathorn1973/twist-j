# C-J-SPLIT-PRIME-NORMONE-TORUS-N: frozen local contract

NON-CANONICAL incubation; provisional identifier; L1. Frozen after the
coordinator's 2026-10-03 UTC collision release, on public main
`5e872c22a18043c8126945a982efad55472cea82`, Public Canon v97.

Carrier: K=Q(j), j a primitive fifth root, O=Z[j], complex conjugation
c(j)=j^-1, and the abstract multiplicative group

    T(K)={x in K^*: x c(x)=1}.

Equality is equality in K. This notation follows the assignment and does
not identify this group with the absolute norm-one torus of the existing
P-J-NORM-TRACE-TANGENT-SEAM-1. Its norm is relative to K^+=Q(sqrt5).

Targets: classify T(K) by exact normalized prime-ideal valuations; test
the proposed abstract isomorphism

    T(K) ~= mu_10 direct_sum direct_sum_(p=1 mod5) Z^2.

Prove the four rational-prime splitting cases and conjugation orbits,
identify the integral-unit kernel, and exhibit a splitting using class
number one. Verify N(1+2j)=11, its four conjugate prime factors, and the
independence modulo mu_10 of (1+2j)/(1+2j^4) and
(1+2j^2)/(1+2j^3) solely through valuations. Explain the marked principal
normalization of J and its limits in other embeddings.

Inherited exact inputs, with no reopening: CYCLOTOMIC-CLASS-NUMBER-ONE [T]
for h(K)=1 and O maximal; CM-ALTERNATING-PENCIL [T], P6, for the integral
relative-norm-one kernel mu_10; J-HARMONIC-SEAM [T] for O^*=mu_10 x <phi>;
and J-PROJECTIONS/J-GOLDEN-BRIDGE for J=phi^-1 j in the marked principal
embedding. Give a short direct verification of the consumed unit-kernel
deduction. Distinguish SPLIT-PRIME-RAPIDITY-CLASS and #1346, which concern
the real-field rapidity shell and its two orientations of one axis.

Method: symbolic theorem proof. Standard unique factorization of fractional
ideals and finite-field Frobenius are explicit algebraic inputs; rational
prime splitting is derived from O=Z[j] and Phi_5 modulo p. No scientific
runtime, enumeration, decimal approximation, or original #1346 code is
needed. Targets were exposed by the assignment; no blindness is claimed.

Zero tolerance: a missing prime type, wrong conjugation stabilizer, omitted
valuation relation, non-surjective claimed valuation map, nontrivial
kernel beyond mu_10, false splitting, incorrect norm or p11 witness, or
wrong normalization rejects the corresponding target. Complete proof
permits local candidate-T; a source/hash discrepancy is STOP.

No topological independence, algebraic-torus dimension inferred from the
abstract free rank, prime-ordering distribution, electromagnetic phase,
native implementation, decoder, occurrence or physical lift is claimed.
Generator choices and prime-pair orientations are explicit and need not
be canonical. No public file, issue, status or existing owner changes.

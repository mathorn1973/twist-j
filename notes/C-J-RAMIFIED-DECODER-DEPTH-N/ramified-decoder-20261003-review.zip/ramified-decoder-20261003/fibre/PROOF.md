# The ramified shear and the declared native fibre group

NON-CANONICAL. **Result: candidate-T**, complete L1 negative classification
in the classes frozen in `CONTRACT.md`. No scientific program or exhaustive
permutation search was run. Existing #1342 is consumed at its stated fibre
scope, not reopened or promoted.

**Theorem.** Let G be the group of maps induced on the native fibre
V=F5^2 by a,b,c,d,e, including all finite fixed words. The ramified shear
S(a,b)=(a,b+a) is not directly in G, is not affinely conjugate to any member
of G, and is not a total surjective set factor of any single member of G
on the full 25-point target. No equivariant factor of this G-action on a
25-point set has an element acting as S.

**1. Verification from the current public bytes.** The native formulas in
`canon/CANON.md` lines 580-584 have last two coordinates

| Generator | Fibre map (q,r) | Centre s in u->2s-u |
| --- | --- | --- |
| a | (q,r) | identity |
| b | (-q,-r) | (0,0) |
| c | (1-q,-r) | (3,0) |
| d | (1-q,1-r) | (3,3) |
| e | (2-q,1-r) | (1,3) |

The centre column uses 2^-1=3 in F5. Each last-coordinate formula is
independent of the four piston coordinates. The separately read source
`reproduce/census/verify.py`, definitions `gen_a` through `gen_e`, gives
the same formulas: its last coordinate `t` is the Canon's `r`,
C_D=(2,1,3,4,1,1), and V_E=(0,0,0,0,1,0). This directly verifies the
consumed assertion of #1342 against its defining public inputs, without
taking its reported enumeration as a premise.

Write F_(sigma,t)(u)=sigma u+t, sigma in {1,-1}. Composition gives

    F_(sigma,t) o F_(tau,s)=F_(sigma*tau,t+sigma*s).

All generators have this form, so G is contained in this 50-map group.
Conversely, in ordinary right-to-left composition, c o b is translation
by (1,0), while d o c is translation by (0,1). Their powers and products
give every translation of V. Composing each with b(u)=-u gives every
F_(-1,t). These 50 maps are distinct (evaluate at 0 to recover t, and at
a nonzero vector to distinguish the two signs). Therefore

    G = {u->sigma u+t: sigma in {1,-1}, t in F5^2}.

This is a proof of the exact complete group; no word-length cutoff is used.

**2. Invariants of the target and source elements.** The independently
proved quotient calculation in `../shear/PROOF.md` yields

    S=I+N, N(a,b)=(0,a), N!=0, N^2=0,
    S^k(a,b)=(a,b+k a).

Thus S has exact order five. Its five fixed points are (0,b). For each
a!=0, the five points (a,b) form one five-cycle. Its cycle type is
therefore 1^5 5^4.

The source group has only the following possibilities:

| Element | Order | Fixed points | Complete cycle type |
| --- | --- | --- | --- |
| identity | 1 | 25 | 1^25 |
| u->u+t, t!=0 | 5 | 0 | 5^5 |
| u->-u+t | 2 | 1 | 1^1 2^12 |

For a nonzero translation, u+k t=u holds exactly when 5 divides k.
For the last row, the square is identity and the unique fixed point is
u=t/2; every other point is paired with a distinct point. This proves
the table for every element, rather than sampling it.

**3. Direct and affine conclusions.** Every element of G has linear part
I or -I. The target linear part I+N is neither. Thus S is not in G.
For h(u)=Pu+c, affine conjugation sends the linear part A to PAP^-1;
both scalar matrices remain themselves. Hence no affine conjugate of an
element of G equals S. The cycle table also independently excludes every
set-theoretic conjugate of an element of G.

**4. The frozen factor classes.** Suppose q:V->Y is a total surjection,
Y=F5^2, and q o g=S o q for some g in G. Both sets have exactly 25
points, so q is a bijection. The equation therefore says S=q g q^-1.
Conjugacy preserves the complete cycle type, contradicting the table.
This proves the exclusion for arbitrary total surjective set maps, and
therefore for every more restrictive affine or linear factor in this class.
Surjectivity is essential to this claim: a constant map to a fixed point
would satisfy semiconjugacy but would not realize the full target action.

For the group-action reading, let rho:G->Sym(Y) be any action and q a
total surjective equivariant map: q(g u)=rho(g)q(u). If rho(g0)=S for
some g0, the same pair (g0,q) contradicts the just-proved single-element
result. This specifies what is and is not meant by a factor of the group
action; it does not assume that a bare target permutation already defines
an action of G.

**Decision and boundary.** The current declared native two-dimensional
fibre action does not realize the ramified shear in any frozen class.
All longer fixed words inside this same fibre group are already covered
by its complete classification. This does not exclude a realization on
the full F5^6 checkpoint, through state-dependent word choice, a counter,
the selected autonomous U, an extended carrier, or another factor class.
The fibre maps alone are not an autonomous model of U: its generator
selector also depends on the piston sum and clock, as the public Canon
states. No physical gate, memory, transfer, occurrence, or L2-L6 inference
is made. No frozen falsifier fired. Source custody is in `SOURCES.tsv`.

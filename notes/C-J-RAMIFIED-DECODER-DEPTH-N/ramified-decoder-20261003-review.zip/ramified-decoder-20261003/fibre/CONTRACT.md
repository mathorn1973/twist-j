# C-U-RAMIFIED-SHEAR-FIBRE-N: frozen local contract

NON-CANONICAL incubation; provisional identifier; L1. Frozen 2026-10-03
after the coordinator's collision release in `../audit/COLLISIONS.md`.
Public source: `mathorn1973/twist-j` main
`5e872c22a18043c8126945a982efad55472cea82`, Public Canon v97.

Source carrier V=F5^2 with coordinates (q,r), and projection
f:F5^6->V from the five exact native generators in Canon lines 580-584
and `reproduce/census/verify.py`. Let G be the permutation group generated
by their induced fibre maps, allowing every finite fixed word. First verify
from these formulas, without relying on a census or the assertion alone,
that G consists exactly of u->sigma u+t, sigma in {1,-1}, t in V.
This consumes only the fibre assertion of existing #1342 and does not
reopen that note or audit its Wigner claims.

Target carrier Y=F5^2, with S(a,b)=(a,b+a), as independently derived in
`../shear/PROOF.md`. If that proof corrects the sign or normal form, stop
and record the correction before applying the comparison; do not change
the equivalence class to rescue an exposed target.

The complete comparison classes are frozen as follows:

1. Direct membership: S is literally one element of G in the stated
   coordinate identification V=Y.
2. Affine conjugacy: h g h^-1=S for some g in G and h(u)=Pu+c with
   P in GL_2(F5), c in F5^2.
3. Single-element set factor: some g in G admits a total surjection
   q:V->Y satisfying q(g(u))=S(q(u)) for every u. No linearity,
   affinity, regularity, or fibre-size hypothesis is imposed on q.
   This is the broad natural cyclic-action semiconjugacy class. Both sets
   have 25 points, so surjectivity itself forces bijectivity.
4. Group-action interpretation: allow any action rho:G->Sym(Y) and total
   surjective equivariant q:V->Y. Ask whether rho(g0)=S for some g0 in G.
   Such data imply class 3, so its exclusion settles this interpretation.

Method: exact generator algebra and invariants (linear part, order, fixed
points and cycle type), before any enumeration. No new scientific runtime
is needed or authorized by this proof-only contract. Targets and #1342's
published conclusions were exposed; no blindness is claimed.

Zero tolerance: an incorrect source projection, incomplete group proof,
wrong invariant, or a map admitted by any frozen class realizing S rejects
the corresponding negative conclusion. Complete proofs permit local
candidate-T only; source/hash discrepancies require STOP.

The scope is the current declared two-dimensional fibre action. It includes
longer fixed words in that same group. It excludes no possible full-F5^6
realization, state-dependent word choice, counter-dependent reader, selected
autonomous U, enlarged carrier, or other equivalence/factor class. It gives
no physical conclusion and changes no public file or status.

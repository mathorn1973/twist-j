# Ordinary disclosed review of the codifferent proof

**Recommendation: ACCEPT within the stated local mathematical scope. No required corrections found.** This is an ordinary independent analytical review, not a blind opponent review, a public gate, or a physical validation. No scientific computation or verifier was executed for this review.

## Reviewed source and exposure

- Reviewed file: `codifferent/PROOF.md`.
- Exact SHA-256: `e59ac9cea53fc6975286b0b77563e601e83e1367fc15a1177e8955321316319a`.
- Contract: `codifferent/PREREG.md`, SHA-256 `0befff213482cb5840099ecfee68d32d0660be9a12fd0ebeaa4e55380205e91b`.
- Public authority pin: `5e872c22a18043c8126945a982efad55472cea82`, Canon v97. The prior collision audit exposed the inherited quartic different/codifferent and trace-dual material in CM-ALTERNATING-PENCIL before this review. The parent disclosed the intended proof and requested particular scrutiny of the pairing convention, monogenic-dual argument, and window falsifier.

## Arithmetic findings

The monogenic-dual proof is sufficient. Lagrange interpolation computes the four initial trace sums; the monic relation for each root supplies the integral recurrence for the subsequent sums needed by the pairing matrix. Reversing the columns gives a triangular integer matrix with diagonal entries one, so its determinant is a unit. Thus the displayed lattices pair perfectly and the claimed dual is exact, not merely a sublattice of the dual. The derivative identity and the inherited ramification identity then give the ideal equality for the different with exponent three. The text correctly avoids identifying chosen generators as elements.

Both ideal-dual formulas have the correct convention for every nonzero fractional ideal. Closure of an ideal under multiplication by O upgrades the trace test to containment in the codifferent. Invertibility then gives the B-dual. Applying the same statement to the conjugate ideal gives the H-dual. H is indeed symmetric and positive over Q: its diagonal value is the sum over embeddings of the squared complex absolute values. Conjugation invariance of the codifferent makes either dual operation involutive. In particular, the H-dual exponent at P depends on the original exponent at conjugate(P); no unjustified identification of these two primes appears.

The stated valuation shifts are exact, including for negative exponents of fractional ideals. The separation from a Euclidean reciprocal lattice is necessary and is made explicitly: an embedding and pairing normalization remain additional data.

## Window falsifier

The cited [Baake–Grimm paper](https://arxiv.org/html/1904.08285v2), equation (4) and the following amplitude formula, was checked. It expresses intensities as squared amplitudes involving the window transform; its density relation supplies the lattice-density factor used here. The sign choice in the Fourier argument has no effect on the central peak.

Within the specified fixed regular cut-and-project scheme, compactness permits a sufficiently distant disjoint translate of the window. The finite union remains regular and doubles its volume. Unit weights and fixed Fourier normalization therefore quadruple the central intensity while preserving the underlying lattice and arithmetic field data. This is a valid falsifier of determination by the field's Dedekind zeta coefficients alone. It is not a falsifier of a different statement that also supplies a window or prescribes a new density normalization, and the proof acknowledges that boundary.

The window construction is an abstract mathematical counterexample, not a construction of a TWIST-J physical carrier. The concluding NOT DERIVED status and explicit missing physical inputs are appropriate. The provenance statement also correctly credits the inherited different rather than claiming that formula as a new result.

## Optional editorial precision

When the note is prepared for broader circulation, define `L` in the diffraction formula explicitly as the cut-and-project lattice in the product space, and specify that `k` ranges over the Fourier module. Neither omission affects the central-peak argument at `k=0`, so this is optional and does not condition acceptance.

No change to the theorem, preregistration, source ownership, or public status is requested by this review.

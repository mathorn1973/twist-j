# Trace duals, the quartic codifferent, and the diffraction boundary

NON-CANONICAL. Arithmetic: **candidate-T** by the proof below. Physical diffraction: **NOT DERIVED**. The proposed universal identification of Bragg intensities with Dedekind zeta coefficients is **false**. Contract SHA-256: `0befff213482cb5840099ecfee68d32d0660be9a12fd0ebeaa4e55380205e91b`. No scientific code was executed for this proof.

## 1. The inherited codifferent, with a direct proof

Let f(X)=Phi_5(X)=X^4+X^3+X^2+X+1. Work in K=Q(j), O=Z[j], lambda=1-j. For the four roots r of f, Lagrange interpolation gives

    sum_r r^m/f'(r) = 0 (0<=m<3), and =1 (m=3).

Indeed these are the leading coefficients of the interpolation polynomials for X^m. For m>=4 the relation f(r)=0 gives an integral recurrence, so every subsequent sum is an integer. Consequently the trace-pairing matrix between the bases (1,j,j^2,j^3) and (1,j,j^2,j^3)/f'(j) has integer entries, zeros whenever its two exponents sum to less than 3, and ones whenever they sum to 3. Its determinant is a unit in Z. Thus these two free Z-modules pair perfectly, proving

    O_B^dual = f'(j)^-1 O,    D_K = (f'(j)).

Differentiate (X-1)f(X)=X^5-1 and evaluate at j:

    (j-1)f'(j)=5j^4.

Since j is a unit and (5)=(lambda)^4, equality of ideals gives

    D_K=(lambda)^3,    O_B^dual=lambda^-3 O.

This is equality of ideals; it does not assert f'(j)=lambda^3 as elements. Conjugation preserves (lambda), since conjugate(lambda)=-j^-1 lambda. It also preserves the different and codifferent.

The different formula and the trace-dual criterion are already public in [CM-ALTERNATING-PENCIL](https://github.com/mathorn1973/twist-j/blob/5e872c22a18043c8126945a982efad55472cea82/canon/CANON.md#cm-alternating-pencil-t). The new document makes the two ideal-pairing conventions and their scope explicit. It does not replace the distinct quadratic different of Q(sqrt(5)).

## 2. Two pairings, two ideal duals

For a nonzero fractional O-ideal I define

    I_B^dual={y in K: Tr(yx) in Z for every x in I},
    I_H^dual={y in K: Tr(y conjugate(x)) in Z for every x in I}.

The second definition uses H(y,x); H is symmetric over Q, by trace invariance under conjugation, so testing the other slot gives the same set. This is a Q-bilinear positive trace form, not a claim that its trace is a K-valued Hermitian form.

For B, the condition is equivalent to yI being contained in D_K^-1. One direction follows immediately by testing 1 in O. Conversely, for every x in I and z in O, zx is again in I, so the assumed trace condition gives Tr(yxz) in Z; hence yx lies in the trace dual of O. Invertibility of nonzero fractional ideals now gives

    I_B^dual = D_K^-1 I^-1.

Applying that statement to conjugate(I) gives, separately,

    I_H^dual = D_K^-1 conjugate(I)^-1.

No identification of I with conjugate(I) is needed or generally valid. For I=O the two formulas coincide. Applying either dual operation twice returns I, which also checks the conjugation convention.

## 3. Exact prime-ideal content

Write I=product_P P^a_P, with a_P integral and finitely supported; d_P=v_P(D_K), so d_(lambda)=3 and all other d_P=0. Then

    v_P(I_B^dual)=-d_P-a_P,
    v_P(I_H^dual)=-d_P-a_conjugate(P).

Increasing a_P by t changes the B-dual exponent at P by -t. It changes the H-dual exponent at conjugate(P) by -t. At conjugation-stable primes these agree. The ramified prime has the additional fixed shift -3. These are exact statements about fractional ideals. A reciprocal Euclidean/Fourier lattice additionally requires a specified embedding and pairing normalization; factors from those conventions cannot be silently discarded.

## 4. A falsifier for the zeta/intensity identification

For a fixed regular cut-and-project scheme, unit point weights, and fixed Fourier convention, the standard model-set formula gives

    I_W(k)=dens(L)^2 |Fourier(1_W)(-k_star)|^2.

In particular I_W(0)=dens(L)^2 vol(W)^2. This dependence on the acceptance window appears explicitly in the diffraction amplitudes of [Baake and Grimm, equations (4) and the following amplitude formula](https://arxiv.org/html/1904.08285v2); the general pure-point framework is given by [Baake and Moody](https://arxiv.org/abs/math/0203030).

Here is an exact counterexample construction. Fix a valid scheme with positive-dimensional Euclidean internal space and a compact regular window W of positive volume. Choose a translate t+W disjoint from W and put W'=W union (t+W); translations can also avoid boundary hits. W' is again a regular window, has twice the volume, and leaves the lattice, number field and Dedekind zeta function unchanged. Nevertheless

    I_W'(0)=4 I_W(0) != I_W(0).

Therefore the field's ideal-counting coefficients cannot alone determine even the central Bragg intensity, let alone the entire diffraction measure. Dedekind's Euler product counts ideals by norm; it is not a Fourier intensity formula. This is our inference from the stated window dependence, not an interpretation claimed by the cited papers. Even if one later chooses a density normalization, the universal assertion as stated has already failed; such an extra normalization would define a different claim.

This falsifier uses an abstract mathematical scheme to test a universal assertion. It supplies no TWIST-J physical cut-and-project carrier. The physical diffraction claim remains NOT DERIVED until a source-owned lattice/carrier, star map, acceptance window, density, weights, Fourier normalization and physical bridge are independently specified. Arithmetic codifferent data alone do not close that obligation.

## 5. Review boundary and disposition

All arithmetic equalities hold for every nonzero fractional O-ideal, with no numerical tolerances. The proof is self-contained relative to the already canonical O and ramification facts. No formal public gate or two-architecture run is claimed. A useful future note would credit the inherited quartic different and focus on the distinct B/H ideal-dual formulas plus the diffraction falsifier; it must not advertise a new physical diffraction theorem.

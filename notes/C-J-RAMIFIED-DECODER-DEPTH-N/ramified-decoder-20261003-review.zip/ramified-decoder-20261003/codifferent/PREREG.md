# C-ZETA5-CODIFFERENT-RECIPROCAL-N: local proof contract

NON-CANONICAL incubation; L1; proof-only lane. Frozen before any new scientific computation. No scientific program is planned or needed. A local file/hash pin is not a public formal-probe pin.

Authority: Public Canon v97, public main `5e872c22a18043c8126945a982efad55472cea82`. Release: `../audit/COLLISIONS.md`. The inherited quartic different and trace-dual criterion already occur in CM-ALTERNATING-PENCIL [T], Canon lines 10811–10824, `probes/P-CM-ALTERNATING-PENCIL-1`. Do not represent their restatement as a new discovery. CM-REAL-DIFFERENT-PRIMARY-SEAM concerns the real quadratic subfield and is a separate carrier.

Carrier: K=Q(j), j a primitive fifth root, O=Z[j], lambda=1-j, and all nonzero fractional O-ideals I. The ordinary pairing is B(x,y)=Tr(xy); the real-valued conjugate pairing is H(x,y)=Tr(x conjugate(y)). Define each dual by testing the first argument against all elements of I in the second argument. Equality is equality of fractional ideals, not equality of chosen generators.

Targets: different (Phi'_5(j))=(lambda^3); O trace dual=lambda^-3 O; I_B^dual=D^-1 I^-1; I_H^dual=D^-1 conjugate(I)^-1; exact prime valuations for both. A complete proof yields candidate-T arithmetic. A missing hypothesis, sign/conjugation error, or false dual equality rejects that formulation with zero tolerance.

Separate universal assertion to test: number-field Dedekind zeta coefficients alone determine general regular-model-set Bragg intensities. Admit varying regular acceptance windows while keeping one cut-and-project lattice/field and Fourier convention fixed. A pair with different intensities and the same field refutes this assertion. This comparison is a mathematical falsifier, not adoption of a TWIST-J physical diffraction model. No physical result is derived without independently frozen carrier, star map, window, density and Fourier normalization.

Proof method: monogenic trace-dual via polynomial interpolation; derivative identity; ideal inversion; conjugation; window-dependence of the standard model-set diffraction formula. Only exact identities, no decimal estimates. External mathematical references are secondary support to the explicit arithmetic proof; the window formula must have a primary citation.

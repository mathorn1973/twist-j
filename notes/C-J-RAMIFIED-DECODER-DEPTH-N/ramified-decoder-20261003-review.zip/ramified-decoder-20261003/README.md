# Ramified decoder review bundle

PUBLIC-content, NON-CANONICAL. Public Canon v97 remains unchanged. Start with the required claim/result/status table and cross-programme synthesis in **[REPORT.md](REPORT.md)**.

| Lane | Main result | Evidence |
| --- | --- | --- |
| 0. Prime-return review | ACCEPT literal #1346; nonunit-source caveat explicit | [Proof review](review/prime-return/PROOF-REVIEW.md), [preregistration](review/prime-return/PREREG.md), [actual run](review/prime-return/RUN.json) |
| 1. Ramified shear | Complete depth-two quotient proof | [Proof](shear/PROOF.md), [contract](shear/CONTRACT.md) |
| 2. Native fibre comparison | Complete negative classification in the frozen fibre/factor classes | [Proof](fibre/PROOF.md), [contract](fibre/CONTRACT.md) |
| 3. Partial residue depth | Both minimum depths 6 by proof; full counts candidate-C | [Result](depth/RESULT.md), [structural proof](depth/STRUCTURAL-PROOF.md), [capacity review](depth/CAPACITY-REVIEW.md), [preregistration](depth/PREREG.md), [frozen verifier](depth/verify.py), [pin](depth/PIN.json), [run](depth/runs/001/RUN.json), [complete census](depth/runs/001/data/CENSUS.json) |
| 4. Relative norm-one group | mu10 times the direct sum of Z² over p=1 mod5 | [Proof](torus/PROOF.md), [contract](torus/CONTRACT.md) |
| 5. Trace dual and diffraction | Arithmetic proof; universal zeta/intensity assertion refuted | [Proof](codifferent/PROOF.md), [preregistration](codifferent/PREREG.md), [review](codifferent/REVIEW.md) |

[Authority](audit/AUTHORITY.md) · [Collision audit](audit/COLLISIONS.md) · [Ordinary coordinator review](audit/COORDINATOR-REVIEW.md) · [Synthesis source custody](audit/SYNTHESIS-SOURCES.json)

Two new locally frozen scientific programs ran: the independent prime-return breaker and the depth census. Both passed on one architecture. Their raw outputs and actual run records are retained. Proof-only lanes did not run a scientific program. Local candidate-T proofs and candidate-C counts are distinguished in the report; there is no public formal pin, two-architecture candidate gate or canonical promotion.

`SHA256SUMS` covers the final bundle. `verify_integrity.py` checks its exact file inventory and hashes without executing science. The full depth partitions are intentionally retained for inspection. Source files remain at pinned public references and local paths; hashes do not pretend to make those external source trees part of this ZIP.

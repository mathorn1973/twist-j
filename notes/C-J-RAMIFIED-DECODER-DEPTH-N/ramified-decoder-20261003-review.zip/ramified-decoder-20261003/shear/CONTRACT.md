# C-J-RAMIFIED-SHEAR-N: frozen local contract

NON-CANONICAL incubation; provisional identifier; L1. Frozen 2026-10-03
after the coordinator's collision release in `../audit/COLLISIONS.md`.
Public source: `mathorn1973/twist-j` main
`5e872c22a18043c8126945a982efad55472cea82`, Public Canon v97.

Carrier: O=Z[j]=Z[X]/(Phi_5(X)), with j a primitive fifth root,
lambda=1-j, J=1+j^2, and R2=O/(lambda^2). Equality is literal ring
equality in this fixed quotient. The marked coordinate epsilon is [lambda].

Targets: prove the ring isomorphism with F5[epsilon]/(epsilon^2), the
unique expression a+b epsilon, J=2(1-epsilon), J^4=1+epsilon,
(J^4)^k=1+k epsilon, the multiplication map (a,b)->(a,b+a), its exact
inverse and order. Distinguish reduction modulo lambda and all claimed
basis dependence. Credit C20-TEICHMULLER-SPLIT [T] as the existing broader
ramified-ring and depth-four unit-split result.

Method: self-contained symbolic proof by quotient presentations and ring
identities. No new scientific program, enumeration, or floating-point
calculation is needed or authorized by this contract. Hashes and file
integrity checks are custody checks, not scientific evidence.

Zero tolerance: an invalid presentation, nonunique representation, wrong
characteristic, sign, inverse, power, exact order, or basis claim rejects
the corresponding target. Complete proof permits local candidate-T only;
an unproved target remains OPEN, and an integrity discrepancy is STOP.

No physical interpretation, native-U realization, decoder, memory, transfer,
gate, occurrence, or cross-layer result is inferred. No public status or
source file changes. The target identities were provided by the user;
this is a proof of exposed targets, not a blind prediction.

# Ramified depth-two multiplication by J

NON-CANONICAL. **Result: candidate-T**, complete L1 proof within
`CONTRACT.md`. No scientific program was run. This is an explicit
depth-two corollary and normal form, not a new claim of ramification or of
the depth-four unit structure already in C20-TEICHMULLER-SPLIT [T].

**Theorem.** For O=Z[j], j a primitive fifth root, lambda=1-j and J=1+j^2,
the assignment epsilon -> [lambda] gives a ring isomorphism

    F5[epsilon]/(epsilon^2) -> O/(lambda^2).

In this marked presentation,

    J=2(1-epsilon),  J^-1=3(1+epsilon),
    J^4=1+epsilon,  J^-4=1-epsilon,
    (J^4)^k=1+k epsilon  (k in Z, coefficient reduced in F5).

Multiplication by J^4 is S(a,b)=(a,b+a); its inverse is
S^-1(a,b)=(a,b-a), and both the unit J^4 and its multiplication operator
have exact order five. The normal-form matrix depends on coordinates;
the nontrivial rank-one unipotent conjugacy class does not.

**Proof of the ring presentation.** Put L=1-X in the defining presentation
O=Z[X]/(Phi_5(X)). Direct binomial expansion gives

    Phi_5(1-L)=L^4-5L^3+10L^2-10L+5.

Consequently

    O/(lambda^2)=Z[L]/(L^2, 5-10L).

The ideals (L^2,5-10L) and (L^2,5) are equal: one inclusion is immediate,
and the other follows from

    (1+2L)(5-10L)+20L^2=5.

Thus this is precisely (Z/5Z)[L]/(L^2). This establishes an isomorphism,
not just equality of cardinalities. In particular the characteristic is
exactly five, epsilon is nonzero, and each element has a unique expression
a+b epsilon with a,b in F5.

**Proof of the action and order.** Since j=1-epsilon,

    J=1+(1-epsilon)^2=2-2epsilon.

The square-zero identity yields

    J^4=2^4(1-epsilon)^4=16(1-4epsilon)=1+epsilon

in characteristic five. The products
(1-epsilon)(1+epsilon)=1 and 2*3=1 prove both inverse formulas.
Induction gives (1+epsilon)^k=1+k epsilon for k>=0; the inverse extends
it to all integers. This equals one exactly when 5 divides k, because
epsilon is a nonzero F5-basis vector. Multiplication acts faithfully on
the ring (evaluate an operator at 1), so its order is also five. Finally,

    (1+epsilon)(a+b epsilon)=a+(b+a)epsilon,

which proves S and its inverse.

**Residue layer versus the first nilpotent layer.** Modulo lambda, J is
the scalar 2 in F5, of exact order four, and J^4 is the identity. Modulo
lambda^2, J^4 is the first nontrivial unipotent action. For completeness,
J itself has exact order twenty here: an exponent killing J must be
divisible by four from its residue, and its quotient by four must be
divisible by five from the order of J^4. The additive matrix is

    S = [[1,0],[1,1]],    N=S-I=[[0,0],[1,0]].

Here N!=0, N^2=0, rank(N)=1, and im(N)=ker(N)=(epsilon). Its fixed
points form precisely the five-point ideal (epsilon), namely a=0.

**What is invariant under change of basis.** Any F5-linear change of
coordinates P replaces the matrix by P^-1 S P. Nonidentity, square-zero
nilpotent part, rank, order and the fixed ideal are intrinsic. The literal
entry 1 in the displayed matrix is a marked-coordinate statement. A
unital dual-number presentation can replace epsilon by epsilon'=c epsilon
for any c in F5^*. These are exactly its F5-algebra automorphisms, since
the nonzero square-zero elements are precisely c epsilon. With the fixed
element J^4 and coordinates a+b'epsilon', the action becomes

    (a,b') -> (a,b'+c^-1 a).

In particular replacing lambda by -lambda reverses this coefficient.
For the other natural uniformizers lambda_r=1-j^r, r=1,2,3,4, one has
lambda_r=r lambda modulo lambda^2, giving coefficient r^-1 for the same
J^4. If the distinguished element is also transported by j->j^r, then
J_r=1+j^(2r) satisfies J_r^4=1+lambda_r and the marked normal form is
again (a,b)->(a,b+a). These observations separate coordinate change from
changing the distinguished arithmetic data.

**Decision and boundary.** All frozen algebraic targets pass by proof;
no falsifier fired. The result describes this quotient ring and its
multiplication map only. Native implementation and every physical reading
remain outside the claim. Sources and inherited scope are in `SOURCES.tsv`.

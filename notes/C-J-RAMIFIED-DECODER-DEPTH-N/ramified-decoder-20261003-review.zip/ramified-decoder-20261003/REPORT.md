# Ramified refinement and the open decoder programme

PUBLIC-content, NON-CANONICAL incubation. Begun 3 October 2026; completed after midnight on 4 October, Europe/Prague. Authority remains Public Canon v97 at main `5e872c22a18043c8126945a982efad55472cea82`. No public status or GitHub content changed. The required decision table comes before the synthesis.

## 1. Results and disposition

| Claim / review | Result | Status | Exactly proves | Does not prove | Collisions / inherited scope | Next gate |
| --- | --- | --- | --- | --- | --- | --- |
| REVIEW-C-J-PRIME-RETURN-COMPATIBILITY-N | ACCEPT #1346 as written | Local review; complete arithmetic arguments; finite breaker candidate-C | Unit-ideal invariance, unit return order, lcm joint orbit, gcd phase compatibility, source-blind counter reading and exact finite emitter size | Same return period for arbitrary nonunit alpha; source information, physical clock or event law | Existing #1346 is reviewed, not reopened; original verify.py unread | Preserve original owner and literal quantifiers; no new claim |
| C-J-RAMIFIED-SHEAR-N | J^4 acts as (a,b)->(a,b+a) on O/(lambda^2) | candidate-T | Exact dual-number presentation, sign, inverse, order five, coordinate-invariant unipotent type | Native contact, memory, transfer or physical gate | Explicit depth-two corollary of C20-TEICHMULLER-SPLIT, not a new ramification theorem | Ordinary public-note review if selected; credit parent |
| C-U-RAMIFIED-SHEAR-FIBRE-N | Shear excluded in the frozen fibre classes | candidate-T | Complete native fibre group {u->+/-u+t}; no direct, affine-conjugate or total surjective 25-to-25 factor realization | No universal obstruction on full F5^6, the counter, state-dependent protocols or extensions | Uses #1342's exact native generators without reopening its representation | Change the carrier/equivalence explicitly before a further realization test |
| C-J-RAMIFIED-DECODER-DEPTH-N | Counts (256,1170,1384,2603,2882,3150,3150,3150); first sufficient/injective depth 6 | Full census candidate-C; both exact minimum-depth decisions candidate-T by separate proof | Same B941, both traces, ideal residues; exact finite partitions and witnesses; norm separation at k6 and thirty disjoint collisions at k5 prove both minima | Global minimum over other observables, finite total memory, physical availability, selected codebook | Refines the partial-depth question expressly excluded by sealed #1283; k4/k8 anchors unchanged | New formal probe with immutable public pin and required architecture checks if selected |
| C-J-SPLIT-PRIME-NORMONE-TORUS-N | T(K) is mu10 times the direct sum of Z^2 over p=1 mod5 | candidate-T | Relative norm-one valuation classification, noncanonical splitting, independent p11 witnesses | Absolute norm-one classification, electromagnetic phases, native generation or physical dimensions | Credits existing unit kernel and class number; distinct from real rapidity and absolute norm-one torus | Review as a separate arithmetic note, not an extension of #1346's clock claim |
| C-ZETA5-CODIFFERENT-RECIPROCAL-N, arithmetic | D=(lambda^3); two distinct ideal-dual formulas | candidate-T | Ordinary versus conjugated trace dual, exact valuation inversion and ramified shift | A selected Euclidean/Fourier normalization or physical reciprocal lattice | Quartic different already in CM-ALTERNATING-PENCIL; real-quadratic seam is separate | Reuse parent; retain only useful ideal-dual clarification |
| C-ZETA5-CODIFFERENT-RECIPROCAL-N, diffraction | Universal zeta/intensity identification refuted; physical model absent | Exact mathematical falsifier; physical NOT DERIVED | Changing the regular window changes intensity with the field/zeta function fixed | A TWIST-J diffraction prediction or a complete physical model | No independently frozen diffraction carrier is supplied by these sources | Freeze scheme, star map, window, density, weights, normalization and physical bridge first |

The detailed proofs, contracts, source hashes, actual execution records and review limits are linked in [README.md](README.md). None of the candidate labels is a canonical promotion. “Independent” in the clock review means separate derivation/code with exposed source outcomes, not an external blind referee.

## 2. What changes for the scalar decoder

Put lambda=1-j. Here D_k means the residue modulo lambda^k; the old rational-modulus D5 is therefore our depth four, and the old D25 is depth eight. The exact public strip has 3150 nonzero integral elements with N(alpha)<=941. Its 145 two-trace classes and the two traces themselves are unchanged. The local census gives:

| k | Ideal residue | Distinct complete D_k keys | Shortfall from 3125 | Full-strip injection |
| --- | --- | ---: | ---: | --- |
| 1 | lambda | 256 | 2869 | no |
| 2 | lambda^2 | 1170 | 1955 | no |
| 3 | lambda^3 | 1384 | 1741 | no |
| 4 | lambda^4=(5) | 2603 | 522 | no |
| 5 | lambda^5 | 2882 | 243 | no |
| 6 | lambda^6 | 3150 | 0 | yes |
| 7 | lambda^7 | 3150 | 0 | yes |
| 8 | lambda^8=(25) | 3150 | 0 | yes |

The primary residue algorithm uses successive exact division by lambda. An independent inverse-lattice calculation checked every one of 36975 equal-trace unordered pairs at all eight depths: 295800 exact congruence comparisons. The original strip digest, mod5 count and mod25 count all matched. First execution passed with unchanged frozen inputs, exit 0 and empty stderr on one Windows AMD64/Python 3.12.10 environment. This is one architecture, despite the two methods.

The structural upper bound is stronger than a finite test. Equal traces imply equal two Galois magnitudes. Thus, for delta=alpha-beta!=0,

    0 < N(delta) <= 16 N(alpha) <= 15056.

Congruence modulo lambda^6 would force 15625=5^6 to divide N(delta), impossible. This proves injection on the entire nonzero integral norm-bounded domain, including its unbounded J orbits. At depth five the exact pair

    alpha=(-3,-5,-3,-3), beta=(2,5,2,2),
    alpha bar(alpha)=beta bar(beta)=13+6 phi,
    (S0,S1)=(32,33), N(alpha)=N(beta)=211,
    beta-alpha=lambda^5(1-2j^2-2j^3), N(beta-alpha)=3125

already proves failure of injection. The source-bound 941 was not lowered or changed.

There is also a complete analytical obstruction to fitting 3125 labels at depth five. Besides this pair, take its J^-1 sigma2 transform, with endpoints (-2,1,1,3) and (3,1,1,-2), and the pair (-6,-6,-5,-4), (-1,-1,5,1). Their respective real-square parameters are (u,v)=(13,6),(13,7),(27,8), and every difference has norm 3125 and is divisible by lambda^5. Multiplying each pair by all ten roots in mu10 gives thirty disjoint colliding pairs. Within a family the two root orbits cannot intersect: a root-of-unity ratio would force the endpoint norm, 211 or 881, to divide the difference norm 3125. Across families the distinct real squares separate them. Therefore the inherited canonical strip count gives

    K5 <= 3150-30 = 3120 < 3125.

Coarser depths cannot improve it. Combined with the depth-six injection, this proves **both minimum depths are exactly 6** without relying on the new complete count K5=2882. This post-run proof uses disclosed census witnesses and was separately checked by hand; it is not a blind prediction. See [structural proof](depth/STRUCTURAL-PROOF.md) and [capacity review](depth/CAPACITY-REVIEW.md). Exact intermediate counts remain candidate-C.

The residue alphabet at depth six has 5^6 elements instead of the mod25 alphabet's 5^8: a factor 25 reduction in this component. That is two base-five residue digits. It is **not** a factor-25 reduction in an entire physical apparatus or total finite storage, because the complete datum still includes two unbounded integer traces. The registered inverse implementation remains the mod25 one. A constructive depth-six inverse can normalize the traces as before, transport the ideal residue by the corresponding J unit, and search the fixed finite strip for its unique matching entry; the present work establishes its mathematical uniqueness, not a released replacement implementation.

## 3. The exact link between phases and decoder ambiguity

There is a useful direct consequence of the proved arithmetic. For nonzero integral alpha,beta, the public two-trace reconstruction gives

    same two traces
      iff alpha bar(alpha)=beta bar(beta)
      iff t=beta/alpha belongs to T(K).

Within such a class, equality of depth-k readings is exactly

    alpha(t-1) in lambda^k O
      iff v_lambda(alpha)+v_lambda(t-1)>=k.

For t=1 use valuation infinity. Relative norm one forces v_lambda(t)=0 because the ramified prime is conjugation-stable. The equation therefore compares phases that are units locally at lambda, while allowing denominators at other split primes. This is the precise connection between the norm-one classification and the residue refinement. It is a derived identity, checked by ordinary review, not a new physical law.

Three distinctions follow. First, the infinite abstract phase group does not make infinitely many admissible integral codewords in one fixed trace class: both complex magnitudes are fixed, so the integral Minkowski lattice has only finitely many points in the resulting bounded set. Second, an arbitrary rational norm-one factor need not preserve integrality, so it is not automatically an admissible decoder operation. Third, nonunit alpha shifts the required local phase resolution. This matches the colon-ideal correction in the clock review and prevents invalid residue cancellation.

The shear at depth two and the scalar inverse at depth six answer different questions. The former identifies a multiplication action on a small ring; the latter separates a chosen norm-bounded arithmetic carrier. Neither provides the other's native realization. Likewise, several J-return clocks follow one common exponent and have lcm capacity; the independent directions in T(K) arise from separately variable prime valuations, not from that one cyclic orbit.

## 4. Synthesis with the other open work in this workspace

Related task finals were read as context, then material claims were checked against local reports and the current public registry. [Source custody](audit/SYNTHESIS-SOURCES.json) pins the files; [thread context](audit/THREAD-CONTEXT.json) preserves the retrieved task titles and finals. Earlier task statements naming v94 or an older main do not override the freshly verified v97 authority.

| Existing line of work | Connection to this result | Obligation still open |
| --- | --- | --- |
| “Propojit dekodér s dynamikou” and #1291–#1297 | Separates reconstruction, autonomous factor, and source-to-record mechanism. New depth-six refinement improves the first. Ramified addresses remain levels of distinction. | A marked address is not an independently writable cell; a chosen local memory law still needs an actual native realization or an explicit architecture extension. |
| “Zpřesnit cíle mapy TWIST-J” | Its marked J,+1 interface preserves ideal divisibility of state differences. The new depth calculation quantifies how much of that filtration separates the fixed scalar carrier. | Marked algebraic operations must be recovered from actual admissible native operations and preparations. A relabeling that preserves transitions cannot supply missing contacts. |
| “Propojit orbity a dělitelnost”, the fixed archive and Omega24 controller | The existing archive classification has 3125 affine realizations and a unique six-link minimum in its frozen raw-coordinate class. The programmed controller owns its head, tape, battery, timing and retained record. | Neither scalar inverse nor fibre shear produces those six addressed contacts, their program, common readiness or a native energy account. Full native coalescence remains distinct from invertibility of individual contacts. |
| Earlier carrier/clock and energy proof notes in this task | One common-time F5^6 checkpoint cannot inject an independent F5^6 archive and an additional independent pentit. The staged source-preserving, additive-energy transfer requires distinguishable equal-energy helper states in its frozen class. | No arithmetic residue refinement increases the number of native prepared states or supplies that helper, locality, clock alignment or preparation. A lossy reading is not the required carrier injection. |
| “Spojit měření a přenos v J” / J contact | Its coherent instrument explicitly funds records; its finite energy-reference family has exact seventh-event weight (2N-1)/(10N^2)>0 for finite N. | The exact seven-zero target fails for that family. These new arithmetic theorems neither remove its reference cost nor derive supplied coherence or one actual outcome. This restricted failure is not a universal measurement no-go. |
| “Doplňit mechanismus výsledku” / v97 packet, preparation and program theorems | Five conditional apparatus theorems are already canonical T with chosen carrier/control/preparation premises. They must be credited rather than described as wholly undefined. | The occurrence branch remains STOP_APPLICABILITY / H_NOT_TESTED. Return periods or phase-group rank do not create its missing event permutation, preparation ensemble or law of occurrence. |

The programme therefore has a precise separation of progress: improved arithmetic resolution, stronger classification of target actions, and explicit conditional apparatuses. The missing native/physical bridges cannot be replaced by counting the same information more finely.

## 5. All current DECODER_CORE frontier items remain open

This table reads the current `REGISTRY.tsv`, `GATES.tsv` and `FRONTIER_PROGRAMS.tsv`; it does not infer scientific dependency from a queue label. All twelve items remain status O.

| Current owner(s) | Queue state | What this package contributes / what remains required |
| --- | --- | --- |
| METRO-REDUCTION-CALCULUS | STOP | No proof of the remaining complete reduction equivalence, forbidden catalogue or unclassified encodings. Ideal coordinate changes alone do not transport the full L5 decision and terminal value. |
| MINIMAL-READ-DERIVATION | STOP | Minimum residue depth in one scalar interface is not the derivation forcing w=1 and beta1 from the complete admissible decoder class. GATE-L5-L1-MINIMAL-READ remains open. |
| SCHEME-DICTIONARY | STOP | Arithmetic sources are sharper, but no measurement scheme, scale/threshold convention, total dictionary or complete acyclic dependency graph is supplied. |
| METRO-ADMISSIBILITY; METRO-ADMISSIBILITY-DIM | STOP; STOP | Neither the R1–R8 residual cover nor the complete multidimensional translated-box decision/certificate is discharged. GATE-L5-L6-METRO-NORMALIZATION remains open. |
| METRO-EDGE-SCALE; DRESS-CROSSCOUNT | BLOCKED; BLOCKED | No canonical physical scale/SI bridge or integer crossing count per observable is derived. |
| QDD-INSTRUMENT-APPARATUS | STOP | The selected ETH-QDD dictionaries are already adopted at D; complete target-independent physical apparatus realization and actual-event sampling remain separate obligations. |
| QDD-INSTRUMENT-CLASS-COMPLETENESS | STOP | The 50-map fibre classification is complete only for that mathematical fibre. It does not classify all physical memories, phases, nonlinear/mixed/irrational or other apparatus families. |
| QDD-TERMINAL-EVENT-SEMANTICS | STOP | No independent law tying completed physical events to the required post-state saturation is supplied. A successful inverse or WRITE flag does not establish it. |
| SQRT-PHI-TIME-GRAVITY | STOP | Prime-return clocks read the counter; no typed branch-independent or branch-selected bridge to the declared decoder clock and gravity readout is derived. |
| TRACEKERNEL-CURVATURE-FORCING | BLOCKED | Neither the complete nonempty admissible L2 class nor Hodge-home forcing is supplied. Codifferent arithmetic and a fibre-specific shear obstruction do not decide that class. |

## 6. Concrete next-work choices

1. **Arithmetic priority:** review the depth-six result, preserve the current strip and both traces, and prepare a new public formal probe only if selected. Pin its accepted code/contract before formal execution and satisfy both required architecture jobs. Keep the old sealed mod25 probe intact. A replacement inverse implementation should separately freeze total recognition, normalization, malformed input handling and exact residue transport.
2. **Native realization priority:** freeze a genuinely source-owned carrier, preparation family, local energy and permitted pair contacts, with the source held fixed through the three contact substeps or with a separately proved schedule change. Use the fibre exclusion and the existing capacity/energy restrictions as entry checks. Do not define the allowed interaction by requiring its answer to be SUM.
3. **Documentation priority:** the shear and ideal-dual material are best treated as explicit corollaries/boundary notes with parent attribution. The relative norm-one classification is a separate useful arithmetic note. None should be marketed as closing the decoder's physical obligations.
4. **Keep occurrence and diffraction separate:** actual-event semantics needs its own source-owned law and applicability data. A diffraction claim needs its independently frozen cut-and-project data. Neither task is discharged by an Euler product, a clock period, or a code-capacity count.

These are reviewable next steps, not automatic publication or a new status assignment. The present task delivers all six requested local branches and their synthesis.
